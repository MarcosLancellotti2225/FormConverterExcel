#!/usr/bin/env python3
"""
Validador de form-definitions de Signframe (INS Costa Rica).

Corre el checklist de validacion (§16 de las convenciones) de forma
deterministica sobre un JSON de definicion de formulario. Si se le pasa
el xlsx de AcroForms del PDF, ademas cruza los sourceName contra los
campos reales del PDF (ground truth).

Uso:
    python3 validate.py form-def.json
    python3 validate.py form-def.json --acroforms acroforms.xlsx

Salida: un reporte por check. Exit code 0 si no hay ERRORES (los WARN no
frenan), 1 si hay al menos un ERROR.
"""

import argparse
import json
import re
import sys

# Caracteres que obligan a envolver el needle de repeaterLookup entre comillas
NEEDLE_SPECIAL = set(",()/")


def load_json(path):
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def iter_fields(defn):
    """Devuelve (field, contexto, repeater_id, sibling_ids) para TODO campo.

    repeater_id = id del repeater contenedor (None si es de nivel seccion).
    sibling_ids = set de ids de los subcampos del mismo repeater (para
    validar referencias internas sin prefijo field_, ver conventions §9).
    """
    def walk(fields, ctx, rep_id, siblings):
        for f in fields or []:
            if not isinstance(f, dict):
                continue
            yield f, ctx, rep_id, siblings
            rc = f.get("repeaterConfig") or {}
            subs = rc.get("fields") or []
            if subs:
                sib = {sf.get("id") for sf in subs if isinstance(sf, dict)}
                yield from walk(subs, f"{ctx} > repeater:{f.get('id')}", f.get("id"), sib)

    for s in defn.get("sections", []) or []:
        sctx = f"section:{s.get('title')}"
        yield from walk(s.get("fields"), sctx, None, set())
        for ss in s.get("subsections", []) or []:
            yield from walk(ss.get("fields"), f"{sctx} > {ss.get('title')}", None, set())


def source_name(f):
    sm = f.get("sourceMeta")
    if isinstance(sm, dict):
        return sm.get("sourceName")
    return None


def parse_cond(val):
    """conditionalVisibility/Required debe ser STRING JSON serializado."""
    if val is None:
        return None, None
    if isinstance(val, dict):
        return None, "es objeto (debe ser string JSON serializado)"
    if not isinstance(val, str):
        return None, f"tipo inesperado {type(val).__name__}"
    try:
        return json.loads(val), None
    except json.JSONDecodeError as exc:
        return None, f"no parsea como JSON: {exc}"


class Report:
    def __init__(self):
        self.errors = []
        self.warns = []
        self.oks = []

    def error(self, check, msg):
        self.errors.append((check, msg))

    def warn(self, check, msg):
        self.warns.append((check, msg))

    def ok(self, check, msg):
        self.oks.append((check, msg))

    def dump(self):
        print("=" * 68)
        print("VALIDACION FORM-DEF SIGNFRAME")
        print("=" * 68)
        for check, msg in self.oks:
            print(f"[OK]    {check}: {msg}")
        for check, msg in self.warns:
            print(f"[WARN]  {check}: {msg}")
        for check, msg in self.errors:
            print(f"[ERROR] {check}: {msg}")
        print("-" * 68)
        print(f"OK: {len(self.oks)}  WARN: {len(self.warns)}  ERROR: {len(self.errors)}")
        return 1 if self.errors else 0


def check_id_matches_sourcename(fields, rep):
    # Convencion: id == "field_"+sourceName. Los PDF renombrados suelen bajar
    # todo a minuscula, asi que se acepta tambien field_+sourceName.lower().
    bad = []
    for f, ctx, rep_id, sib in fields:
        sn = source_name(f)
        if sn is None:
            continue
        fid = f.get("id")
        # sourceNames de repeater traen indice de array: campo[N]. El id se
        # sanitiza reemplazando [ ] . por _ (colapsando repetidos). Se aceptan
        # tanto la forma exacta como la .lower() de esa sanitizacion.
        def _san(x):
            return re.sub(r"_+", "_", re.sub(r"[\[\].]+", "_", str(x))).strip("_")
        valid = {
            "field_" + str(sn),
            "field_" + str(sn).lower(),
            "field_" + _san(sn),
            "field_" + _san(sn).lower(),
        }
        if fid not in valid:
            bad.append(f"{fid!r} != field_{sn!r} (ni su lower/sanitizado)  ({ctx})")
    if bad:
        rep.error("id==field_+sourceName", f"{len(bad)} desalineados:\n     " + "\n     ".join(bad))
    else:
        rep.ok("id==field_+sourceName", "todos los campos con sourceMeta cumplen (case-insensitive)")


def check_dup_ids(fields, rep):
    # Los subcampos de un repeater viven en su propio scope: dos repeaters
    # pueden tener cada uno un subcampo "nombre" sin colisionar. Solo se
    # marcan colisiones entre ids de nivel seccion, o dentro del mismo repeater.
    from collections import Counter
    top = [f.get("id") for f, _c, rep_id, _s in fields if rep_id is None]
    dups = {k: v for k, v in Counter(top).items() if v and v > 1}
    per_rep = {}
    for f, _c, rep_id, _s in fields:
        if rep_id is not None:
            per_rep.setdefault(rep_id, []).append(f.get("id"))
    rep_dups = {}
    for rid, ids in per_rep.items():
        d = {k: v for k, v in Counter(ids).items() if v and v > 1}
        if d:
            rep_dups[rid] = d
    if dups or rep_dups:
        msg = f"nivel seccion: {dups or '0'}; dentro de un mismo repeater: {rep_dups or '0'}"
        rep.error("ids duplicados", msg)
    else:
        rep.ok("ids duplicados", "0 duplicados (subcampos de repeater se cuentan por scope)")


def check_conditions(fields, rep):
    bad = []
    for f, ctx, rep_id, sib in fields:
        for key in ("conditionalVisibility", "conditionalRequired"):
            parsed, err = parse_cond(f.get(key))
            if err:
                bad.append(f"{f.get('id')} .{key}: {err}  ({ctx})")
                continue
            if not parsed:
                continue
            for cond in parsed.get("conditions", []) or []:
                fid = cond.get("fieldId", "")
                # Dentro de un repeater, referenciar un subcampo hermano por su
                # id pelado (sin field_) es valido (conventions §9).
                if str(fid).startswith("field_"):
                    continue
                # Visibilidad condicionada al contenido de un repeater:
                # fieldId especial __rep__:<repeaterId>:item:<subFieldId> (conventions §18).
                if str(fid).startswith("__rep__:"):
                    continue
                # Subseccion referida por su id de subseccion: __sub__:<id>.
                if str(fid).startswith("__sub__:"):
                    continue
                if rep_id is not None and fid in sib:
                    continue
                bad.append(f"{f.get('id')} .{key}: fieldId {fid!r} sin prefijo 'field_'  ({ctx})")
    if bad:
        rep.error("conditionalVisibility/Required", f"{len(bad)} problemas:\n     " + "\n     ".join(bad))
    else:
        rep.ok("conditionalVisibility/Required", "todas son string JSON valido con fieldId prefijado")


def check_checkbox_true(fields, rep):
    """Checkboxes que pintan el PDF: en autoFillConcat el text.value debe ser true (no 'X')."""
    bad = []
    for f, ctx, rep_id, sib in fields:
        af = f.get("autoFillConcat") or {}
        for p in af.get("parts", []) or []:
            if p.get("kind") == "text" and isinstance(p.get("value"), str) and p["value"].strip().upper() == "X":
                bad.append(f"{f.get('id')} tiene part text value={p['value']!r} (deberia ser true)  ({ctx})")
    if bad:
        rep.error("checkbox pinta con true", f"{len(bad)} casos:\n     " + "\n     ".join(bad))
    else:
        rep.ok("checkbox pinta con true", "ningun part text usa 'X' para pintar")


def check_equals_key(fields, rep):
    """En autoFillConcat con op:equals la clave correcta es 'values' (con s)."""
    bad = []
    for f, ctx, rep_id, sib in fields:
        af = f.get("autoFillConcat") or {}
        for p in af.get("parts", []) or []:
            cond = p.get("condition") or {}
            if cond.get("op") == "equals" and "values" not in cond:
                bad.append(f"{f.get('id')} usa op:equals sin clave 'values'  ({ctx})")
    if bad:
        rep.error("autoFillConcat op:equals", f"{len(bad)} casos:\n     " + "\n     ".join(bad))
    else:
        rep.ok("autoFillConcat op:equals", "usan la clave 'values'")


def check_substring_syntax(fields, rep):
    """Substring correcto: transforms:[{kind:'substring',start,end}]. La sintaxis vieja transform:{op} no funciona."""
    bad = []
    for f, ctx, rep_id, sib in fields:
        af = f.get("autoFillConcat") or {}
        for p in af.get("parts", []) or []:
            if "transform" in p and "transforms" not in p:
                bad.append(f"{f.get('id')} usa 'transform' (sintaxis vieja, no funciona)  ({ctx})")
            for t in p.get("transforms", []) or []:
                if "kind" not in t:
                    bad.append(f"{f.get('id')} transform sin 'kind'  ({ctx})")
    if bad:
        rep.error("substring/transforms", f"{len(bad)} casos:\n     " + "\n     ".join(bad))
    else:
        rep.ok("substring/transforms", "usan transforms:[{kind,...}]")


def check_repeater_lookup_needles(fields, rep):
    """needles con , ( ) / deben ir entre comillas SOLO cuando hay varios needles
    separados por coma (para no romper el split). Un needle unico con match=equals
    NO debe llevar comillas: se compara literal contra el valor del select, y las
    comillas romperian la coincidencia. Ver conventions §repeaterLookup."""
    bad = []
    for f, ctx, rep_id, sib in fields:
        af = f.get("autoFillConcat") or {}
        for p in af.get("parts", []) or []:
            if p.get("kind") != "repeaterLookup":
                continue
            needle = p.get("needles", "")
            if not isinstance(needle, str):
                continue
            match = p.get("match")
            wrapped = needle.strip().startswith('"') and needle.strip().endswith('"')
            # needle unico con equals: NO debe ir entre comillas
            if match == "equals" and wrapped:
                bad.append(f"{f.get('id')} needle {needle!r} con match=equals NO debe ir entre comillas (rompe la coincidencia)  ({ctx})")
                continue
            # varios needles (coma fuera de comillas) con caracter especial: deben ir entrecomillados
            has_special = any(c in NEEDLE_SPECIAL for c in needle)
            if has_special and not wrapped and match != "equals":
                bad.append(f"{f.get('id')} needle {needle!r} tiene caracter especial y no esta entre comillas  ({ctx})")
    if bad:
        rep.error("repeaterLookup needles", f"{len(bad)} casos:\n     " + "\n     ".join(bad))
    else:
        rep.ok("repeaterLookup needles", "needles: unico con equals sin comillas, multiples entrecomillados")


def check_order_nonzero(fields, rep):
    """Radios desdoblados: order explicito y != 0 (Signframe apila los 0)."""
    bad = []
    for f, ctx, rep_id, sib in fields:
        if f.get("type") in ("radio",) and f.get("order") in (0, None):
            bad.append(f"{f.get('id')} type=radio con order={f.get('order')!r}  ({ctx})")
    if bad:
        rep.warn("radio order != 0", f"{len(bad)} casos:\n     " + "\n     ".join(bad))
    else:
        rep.ok("radio order != 0", "los radios tienen order explicito distinto de 0")


def check_pdf_painted(fields, rep):
    """Campos con sourceMeta que quiza NO pinten: sin autoFillConcat, sin prefillKey y hidden=true.

    Un slot puede recibir su valor por el slotMappings de un repeater (patron §9):
    esos targetFieldId SI pintan aunque no tengan autoFillConcat propio.
    """
    # recolectar todos los targets de slotMappings de todos los repeaters
    slot_targets = set()
    for f, _c, _r, _s in fields:
        rc = f.get("repeaterConfig") or {}
        for sm in rc.get("slotMappings") or []:
            if sm.get("targetFieldId"):
                slot_targets.add(sm["targetFieldId"])
    suspicious = []
    for f, ctx, rep_id, sib in fields:
        if not f.get("sourceMeta") or f.get("type") == "repeater":
            continue
        paints = (
            bool(f.get("autoFillConcat"))
            or bool(f.get("prefillKey"))
            or f.get("hidden") is not True
            or f.get("id") in slot_targets
        )
        if not paints:
            suspicious.append(f"{f.get('id')} hidden=true sin autoFillConcat/prefillKey/slotMapping  ({ctx})")
    if suspicious:
        rep.warn("campos del PDF que pintan", f"{len(suspicious)} sospechosos (revisar si es intencional, p.ej. vigencia/firma):\n     " + "\n     ".join(suspicious))
    else:
        rep.ok("campos del PDF que pintan", "todos los campos con sourceMeta pintan (autoFillConcat, prefillKey, visible o slotMapping)")


def check_acroforms(fields, rep, acroforms_path):
    try:
        import openpyxl  # noqa
    except ImportError:
        rep.warn("sourceName vs AcroForms", "openpyxl no instalado: pip install openpyxl --break-system-packages")
        return
    import openpyxl
    wb = openpyxl.load_workbook(acroforms_path, read_only=True, data_only=True)
    ws = wb.active
    header = [str(c.value).strip().lower() if c.value else "" for c in next(ws.iter_rows(max_row=1))]
    # heuristica: busca la columna con el nombre del campo
    name_col = None
    for i, h in enumerate(header):
        if h in ("name", "fieldname", "field", "sourcename", "acroform", "nombre"):
            name_col = i
            break
    if name_col is None:
        name_col = 0
        rep.warn("sourceName vs AcroForms", f"no reconoci la columna de nombre; uso la 1a ({header[:1]})")
    acro = set()
    for row in ws.iter_rows(min_row=2):
        v = row[name_col].value
        if v:
            acro.add(str(v).strip())
    json_names = {source_name(f) for f, _c, _r, _s in fields if source_name(f)}
    invented = sorted(json_names - acro)
    missing = sorted(acro - json_names)
    if invented:
        rep.error("sourceName vs AcroForms", f"{len(invented)} sourceName en el JSON que NO existen en el PDF:\n     " + "\n     ".join(invented))
    if missing:
        rep.warn("sourceName vs AcroForms", f"{len(missing)} campos del PDF sin mapear en el JSON:\n     " + "\n     ".join(missing))
    if not invented and not missing:
        rep.ok("sourceName vs AcroForms", f"los {len(json_names)} sourceName coinciden 1:1 con el PDF")


def check_embedded_positions(fields, rep, defn):
    """Cruza sourceName contra _sourcePdf.fieldPositions (ground truth embebido)."""
    positions = ((defn.get("_sourcePdf") or {}).get("fieldPositions")) or []
    if not positions:
        rep.warn("sourceName vs PDF", "no hay --acroforms ni _sourcePdf.fieldPositions embebidas")
        return
    acro = {p.get("sourceName") for p in positions if p.get("sourceName")}
    json_names = {source_name(f) for f, _c, _r, _s in fields if source_name(f)}
    invented = sorted(n for n in (json_names - acro) if n)
    missing = sorted(n for n in (acro - json_names) if n)
    if invented:
        rep.error("sourceName vs PDF", f"{len(invented)} sourceName en el JSON que NO existen en el PDF (no van a pintar):\n     " + "\n     ".join(invented))
    if missing:
        rep.warn("sourceName vs PDF", f"{len(missing)} campos del PDF sin mapear (revisar si es intencional, p.ej. vigencia):\n     " + "\n     ".join(missing))
    if not invented and not missing:
        rep.ok("sourceName vs PDF", f"los {len(json_names)} sourceName coinciden con las fieldPositions embebidas")


def check_ref_case(fields, rep):
    """radioGroupFields / autoFillConcat que apuntan a ids inexistentes por
    diferencia de mayusculas. Si el grupo no se forma, los radios se renderizan
    como texto suelto sin casillas (conventions §25.1)."""
    ids = {f.get("id") for f, _c, _r, _s in fields}
    lower = {}
    for f, _c, _r, _s in fields:
        fid = f.get("id")
        if fid:
            lower.setdefault(str(fid).lower(), fid)
    bad = []
    for f, ctx, _r, _s in fields:
        for x in f.get("radioGroupFields") or []:
            if x not in ids:
                hint = lower.get(str(x).lower())
                extra = f" (deberia ser {hint!r})" if hint else " (no existe)"
                bad.append(f"{f.get('id')} .radioGroupFields -> {x!r}{extra}  ({ctx})")
        af = f.get("autoFillConcat") or {}
        for x in af.get("sourceFieldIds") or []:
            if x not in ids and str(x).lower() in lower:
                bad.append(f"{f.get('id')} .autoFillConcat.sourceFieldIds -> {x!r} (case, deberia ser {lower[str(x).lower()]!r})  ({ctx})")
        for p in af.get("parts") or []:
            x = p.get("fieldId")
            if x and x not in ids and str(x).lower() in lower:
                bad.append(f"{f.get('id')} .autoFillConcat.parts -> {x!r} (case, deberia ser {lower[str(x).lower()]!r})  ({ctx})")
    if bad:
        rep.error("referencias entre campos", f"{len(bad)} rotas:\n     " + "\n     ".join(bad))
    else:
        rep.ok("referencias entre campos", "radioGroupFields y autoFillConcat apuntan a ids existentes")


def check_order_dupes(sections, rep):
    """order duplicado o nulo dentro de una subseccion: el render ubica los campos
    en posicion aleatoria o 'de la nada' (conventions §25.3)."""
    bad = []
    for s in sections:
        conts = [("section:" + str(s.get("title")), s.get("fields") or [])]
        for ss in s.get("subsections") or []:
            conts.append((str(s.get("title")) + " > " + str(ss.get("title")), ss.get("fields") or []))
        for ctx, fs in conts:
            visibles = [f for f in fs if isinstance(f, dict) and not f.get("hidden")]
            seen = {}
            nulls = []
            for f in visibles:
                o = f.get("order")
                if o in (None, 0):
                    nulls.append(f.get("id"))
                else:
                    seen.setdefault(o, []).append(f.get("id"))
            dupes = {o: v for o, v in seen.items() if len(v) > 1}
            if dupes:
                bad.append(f"{ctx}: order duplicado {dict(list(dupes.items())[:3])}")
            if nulls:
                bad.append(f"{ctx}: {len(nulls)} campos visibles sin order ({nulls[:3]})")
    if bad:
        rep.warn("order de los campos", f"{len(bad)} contenedores con problemas:\n     " + "\n     ".join(bad))
    else:
        rep.ok("order de los campos", "sin order duplicado ni nulo en campos visibles")


def check_never_blocking_paint(fields, rep):
    """Slots ocultos con NEVER que ademas tienen autoFillConcat: el NEVER bloquea
    el pintado, el campo no vuelca al PDF (conventions §25.2)."""
    bad = []
    for f, ctx, _r, _s in fields:
        if not f.get("sourceMeta"):
            continue
        cv = f.get("conditionalVisibility")
        if cv and "NEVER" in str(cv) and f.get("autoFillConcat"):
            bad.append(f"{f.get('id')} oculto con NEVER pero tiene autoFillConcat (no va a pintar)  ({ctx})")
    if bad:
        rep.warn("NEVER que bloquea el pintado", f"{len(bad)} casos (usar hidden:true sin conditionalVisibility):\n     " + "\n     ".join(bad))
    else:
        rep.ok("NEVER que bloquea el pintado", "ningun slot con autoFillConcat esta bloqueado por NEVER")


def check_radio_group_label(fields, rep):
    """Cada grupo de radios deberia tener la PREGUNTA en radioGroupLabel; si no,
    el render muestra la primera opcion como titulo (conventions §20)."""
    groups = {}
    for f, ctx, _r, _s in fields:
        if f.get("type") == "radio" and f.get("radioGroupFields"):
            key = tuple(sorted([str(f.get("id"))] + [str(x) for x in f["radioGroupFields"]]))
            groups.setdefault(key, []).append((f, ctx))
    missing = []
    for key, g in groups.items():
        if not any(f.get("radioGroupLabel") for f, _ in g):
            missing.append(f"{g[0][0].get('id')} y {len(g)-1} mas  ({g[0][1]})")
    if missing:
        rep.warn("pregunta del grupo de radios", f"{len(missing)} grupos sin radioGroupLabel:\n     " + "\n     ".join(missing))
    else:
        rep.ok("pregunta del grupo de radios", "todos los grupos de radios tienen su radioGroupLabel")


def main():
    ap = argparse.ArgumentParser(description="Validador de form-defs de Signframe")
    ap.add_argument("form_def", help="ruta al JSON de definicion")
    ap.add_argument("--acroforms", help="xlsx de AcroForms del PDF (ground truth de sourceName)")
    args = ap.parse_args()

    defn = load_json(args.form_def)
    fields = list(iter_fields(defn))
    rep = Report()

    rep.ok("carga", f"{len(fields)} campos en {len(defn.get('sections', []))} secciones")
    check_id_matches_sourcename(fields, rep)
    check_dup_ids(fields, rep)
    check_conditions(fields, rep)
    check_checkbox_true(fields, rep)
    check_equals_key(fields, rep)
    check_substring_syntax(fields, rep)
    check_repeater_lookup_needles(fields, rep)
    check_order_nonzero(fields, rep)
    check_pdf_painted(fields, rep)
    # checks de errores frecuentes (conventions §25)
    check_ref_case(fields, rep)
    check_order_dupes(defn.get("sections", []), rep)
    check_never_blocking_paint(fields, rep)
    check_radio_group_label(fields, rep)
    if args.acroforms:
        check_acroforms(fields, rep, args.acroforms)
    else:
        check_embedded_positions(fields, rep, defn)

    sys.exit(rep.dump())


if __name__ == "__main__":
    main()
