#!/usr/bin/env python3
"""
Chequeo estructural del PDF renombrado, ANTES de importarlo en Signframe.

Detecta lo que hace que el importador pierda campos o los importe con el tipo
equivocado, y que no se ve en Acrobat. Ver references/etapa0-pdf.md.

    python3 check_pdf.py <pdf> [--form-def <form-definition.json>]

Con --form-def ademas cruza los sourceName del form-def contra el PDF.

Salida: ERROR = el import va a salir mal. WARN = revisar.
"""
import sys, re, json, argparse, collections

try:
    from pypdf import PdfReader
    from pypdf.generic import IndirectObject
except ImportError:
    sys.exit("falta pypdf:  pip install pypdf --break-system-packages")

ERRORS, WARNS, OKS = [], [], []


def err(rule, msg, who=""):
    ERRORS.append((rule, who, msg))


def warn(rule, msg, who=""):
    WARNS.append((rule, who, msg))


def ok(msg):
    OKS.append(msg)


def full_name(o):
    """Nombre completo concatenando el /T de cada nivel (raw dict walk)."""
    parts, guard = [], 0
    while o is not None and guard < 12:
        if isinstance(o, IndirectObject):
            o = o.get_object()
        t = o.get("/T")
        if t is not None:
            parts.append(str(t))
        o = o.get("/Parent")
        guard += 1
    return ".".join(reversed(parts))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pdf")
    ap.add_argument("--form-def", dest="fd", default=None)
    a = ap.parse_args()

    r = PdfReader(a.pdf)
    widgets = []
    for pi, pg in enumerate(r.pages, 1):
        for annot in (pg.get("/Annots") or []):
            w = annot.get_object()
            if w.get("/Subtype") != "/Widget":
                continue
            widgets.append((pi, full_name(w), w))

    names = [n for _, n, _ in widgets]
    uniq = sorted(set(names))
    print(f"{a.pdf}: {len(r.pages)} pag | {len(widgets)} widgets | {len(uniq)} nombres unicos")

    # --- E1: widgets sin /FT propio -------------------------------------
    huerfanos = [(n, pi) for pi, n, w in widgets if w.get("/FT") is None]
    if huerfanos:
        for n, pi in huerfanos:
            err("E1", f"widget sin /FT propio (el nombre cuelga del padre): "
                      f"el importador lo va a saltear. pag {pi}", n or "(sin nombre)")
    else:
        ok(f"E1: los {len(widgets)} widgets llevan su /FT propio")

    # --- E2: checkboxes sin /AP o sin /DA --------------------------------
    sin_ap, sin_da, estados = [], [], collections.Counter()
    for pi, n, w in widgets:
        ft = w.get("/FT") or (w.get("/Parent").get_object().get("/FT") if w.get("/Parent") else None)
        if str(ft) != "/Btn":
            continue
        apd = w.get("/AP")
        apd = apd.get_object() if apd else None
        if not apd or not apd.get("/N"):
            sin_ap.append(n)
        else:
            for k in apd.get("/N").get_object().keys():
                if str(k) != "/Off":
                    estados[str(k)] += 1
        if w.get("/DA") is None and (not w.get("/Parent") or w.get("/Parent").get_object().get("/DA") is None):
            sin_da.append(n)
    if sin_ap:
        err("E2", f"checkbox sin /AP/N: no dibuja el tilde y autoFillConcat no lo pinta "
                  f"({len(sin_ap)}): {', '.join(sin_ap[:6])}")
    if sin_da:
        err("E2", f"checkbox sin /DA ({len(sin_da)}): {', '.join(sin_da[:6])}")
    if estados:
        ok(f"E2: estados de exportacion en uso: {dict(estados)}")
        if len(estados) > 1:
            warn("E2", f"hay mas de un estado de exportacion: {dict(estados)}. "
                       f"En los formularios del INS suele ser 'Si' (con tilde) en todos")

    # --- E2b: tipos nativos en uso ---------------------------------------
    tipos = collections.Counter()
    for _, n, w in widgets:
        ft = w.get("/FT") or (w.get("/Parent").get_object().get("/FT") if w.get("/Parent") else None)
        tipos[str(ft)] += 1
    ok(f"E2: tipos nativos: {dict(tipos)}")
    if tipos.get("/Ch"):
        chs = [n for _, n, w in widgets
               if str(w.get("/FT") or (w.get("/Parent").get_object().get("/FT") if w.get("/Parent") else None)) == "/Ch"]
        warn("E2", f"hay {tipos['/Ch']} campo(s) /Ch (lista desplegable): {', '.join(chs[:6])}. "
                   f"Los formularios del INS casi no usan /Ch; si alguno deberia ser un "
                   f"checkbox, Signframe lo va a importar como multiselect y no se va a poder marcar")

    # --- E3: higiene de nombres y valores --------------------------------
    dup = {k: v for k, v in collections.Counter(names).items() if v > 1}
    if dup:
        warn("E3", f"nombres con mas de un widget (multi-widget): {dup}")
    else:
        ok("E3: 0 multi-widget")

    malos = [n for n in uniq if re.search(r"[^a-z0-9_]", n)]
    if malos:
        err("E3", f"nombres fuera de [a-z0-9_] ({len(malos)}): {', '.join(malos[:8])}")
    else:
        ok("E3: todos los nombres en snake_case limpio")

    sucios = collections.Counter()
    for _, n, w in widgets:
        for k in ("/V", "/DV", "/TU", "/TM"):
            if w.get(k) is not None:
                sucios[k] += 1
    if sucios:
        err("E3", f"valores heredados del PDF original sin limpiar: {dict(sucios)}")
    else:
        ok("E3: 0 valores /V /DV /TU /TM sucios")

    # --- cruce contra el form-def ---------------------------------------
    if a.fd:
        doc = json.load(open(a.fd, encoding="utf-8"))
        F = []

        def walk(o):
            if isinstance(o, dict):
                if "id" in o and "type" in o:
                    F.append(o)
                for v in o.values():
                    walk(v)
            elif isinstance(o, list):
                for v in o:
                    walk(v)

        walk(doc.get("sections", []))
        sm = {f["sourceMeta"]["sourceName"] for f in F if f.get("sourceMeta")}
        falta_fd = sorted(set(uniq) - sm)
        falta_pdf = sorted(sm - set(uniq))
        if falta_fd:
            warn("FD", f"en el PDF y sin campo en el form-def ({len(falta_fd)}): {', '.join(falta_fd[:8])}")
        if falta_pdf:
            err("FD", f"en el form-def y NO en el PDF ({len(falta_pdf)}): {', '.join(falta_pdf[:8])}")
        if not falta_fd and not falta_pdf:
            ok(f"FD: los {len(sm)} sourceName del form-def coinciden con el PDF")
        fp = (doc.get("_sourcePdf") or {}).get("fieldPositions") or []
        if fp and len(fp) != len(uniq):
            err("FD", f"_sourcePdf.fieldPositions tiene {len(fp)} entradas y el PDF "
                      f"{len(uniq)} campos: el import perdio campos, hay que reimportar")

    # --- salida ----------------------------------------------------------
    print("-" * 68)
    for m in OKS:
        print(f"[OK]    {m}")
    for rule, who, msg in WARNS:
        print(f"[WARN]  [{rule}] {who + ': ' if who else ''}{msg}")
    for rule, who, msg in ERRORS:
        print(f"[ERROR] [{rule}] {who + ': ' if who else ''}{msg}")
    print("-" * 68)
    print(f"OK: {len(OKS)}  WARN: {len(WARNS)}  ERROR: {len(ERRORS)}")
    return 1 if ERRORS else 0


if __name__ == "__main__":
    sys.exit(main())
