#!/usr/bin/env python3
"""
Linter de reglas de plataforma Signframe.

Complementa validate.py: aquel chequea la convencion del form-def (sourceMeta,
ids, catalogos); este chequea las reglas de RUNTIME verificadas contra el codigo
fuente de Signframe (references/platform-rules.md).

    python3 lint_platform.py form-definition.json [--json-esperado ejemplo.json]

Salida: ERROR = rompe la salida. WARN = revisar, puede ser intencional.
"""
import json, re, sys, argparse, collections

ERRORS = []
WARNS = []


def err(rule, msg, who=""):
    ERRORS.append((rule, who, msg))


def warn(rule, msg, who=""):
    WARNS.append((rule, who, msg))


def walk(doc):
    """Campos de nivel seccion y subseccion (no subcampos de repeater)."""
    for s in doc.get("sections", []):
        for f in (s.get("fields") or []):
            yield s.get("title"), None, f
        for sub in (s.get("subsections") or []):
            for f in (sub.get("fields") or []):
                yield s.get("title"), sub.get("title"), f


def subfields(f):
    """(cfg_tag, subcampo) de un repeater y su child."""
    rc = f.get("repeaterConfig") or {}
    for it in (rc.get("fields") or []):
        yield "item", it
    ch = rc.get("child") or {}
    for it in (ch.get("fields") or []):
        yield "subitem", it


def parse_cv(cv):
    if not cv:
        return None
    try:
        return json.loads(cv) if isinstance(cv, str) else cv
    except Exception:
        return "INVALID"


def base_from_pattern(pat):
    return re.sub(r"\[\{[ij]\d?\}\]", "[]", pat).replace(".{sub}", "")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("formdef")
    ap.add_argument("--json-esperado", dest="esperado")
    a = ap.parse_args()

    d = json.load(open(a.formdef, encoding="utf-8"))
    F = list(walk(d))
    IDS = {f["id"] for _, _, f in F}

    # ---------------- P1: jsonOutputPath manda ----------------
    for _, _, f in F:
        sj, jp = f.get("salidaJSON"), f.get("jsonOutputPath")
        if f.get("type") == "repeater":
            continue
        if sj and not jp:
            err("P1", "tiene salidaJSON pero no jsonOutputPath: no va a escribir nada", f["id"])
        elif sj and jp and sj.strip() != jp.strip():
            err("P1", f"salidaJSON != jsonOutputPath ({sj} / {jp}); manda jsonOutputPath", f["id"])

    # ---------------- P4: repeaters ----------------
    reps = [f for _, _, f in F if f.get("type") == "repeater"]
    for f in reps:
        rc = f.get("repeaterConfig") or {}
        pat = rc.get("jsonSlotPattern")
        if f.get("jsonOutputPath") or f.get("salidaJSON"):
            err("P4", "un repeater no debe tener jsonOutputPath/salidaJSON: emite "
                      "el valor crudo y sale '[object Object]'", f["id"])
        if not pat:
            if not f.get("excludeFromJson"):
                err("P4", "repeater sin jsonSlotPattern: va a colgar una clave con el "
                          "id crudo en la raiz del JSON", f["id"])
        else:
            if "{sub}" not in pat:
                err("P4", f"jsonSlotPattern sin {{sub}}: {pat}", f["id"])
            if "[{i1}]" in pat:
                err("P4", "usa {i1} (1-based): la posicion 0 del array queda en null. "
                          "Usar {i} o {i0}", f["id"])
            if f.get("excludeFromJson"):
                warn("P4", "excludeFromJson NO apaga un repeater. Para que no emita, "
                           "vaciar jsonSlotPattern", f["id"])
        ch = rc.get("child") or {}
        if ch.get("fields"):
            cpat = ch.get("jsonSlotPattern")
            if not cpat:
                err("P4", "child sin jsonSlotPattern", f["id"])
            elif "{j" not in cpat:
                err("P4", f"el patron del child debe usar {{j}}/{{j0}} para el subitem: {cpat}", f["id"])
            warn("P5", "el subrepeater no se puede condicionar y sus subcampos no ven "
                       "al item padre. Verificar que corresponda mostrarlo siempre", f["id"])

    # colision array/objeto (P9)
    owned = {}
    for f in reps:
        rc = f.get("repeaterConfig") or {}
        for cfg in (rc, rc.get("child") or {}):
            p = cfg.get("jsonSlotPattern")
            if p:
                owned[base_from_pattern(p)] = f["id"]
    for _, _, f in F:
        if f.get("type") == "repeater" or f.get("excludeFromJson"):
            continue
        p = f.get("jsonOutputPath")
        if not isinstance(p, str):
            continue
        for nodo, dueno in owned.items():
            plain = nodo.replace("[]", "")
            if p.startswith(plain + ".") and p != plain:
                err("P9", f"escribe dentro de '{plain}', que es un array de {dueno}. "
                          "Va a caer en el indice [0] o pisar el array", f["id"])
                break

    # ---------------- P2: booleanos ----------------
    for _, _, f in F:
        if f.get("type") in ("radio", "checkbox"):
            cj = f.get("checkedJsonValue")
            if isinstance(cj, str) and cj.strip().lower() in ("true", "false") and f.get("jsonOutputPath"):
                err("P2", f"radio/checkbox con checkedJsonValue='{cj}' emite STRING. "
                          "Para booleano nativo hace falta un helper type='boolean'", f["id"])

    # ---------------- P6: subcampos de repeater ----------------
    for f in reps:
        for tag, it in subfields(f):
            t = it.get("type")
            if t in ("boolean", "number"):
                err("P6", f"subcampo '{it.get('id')}' es type={t}: dentro de un repeater "
                          "se emite crudo, no tipado", f["id"])
            if t == "select":
                warn("P6", f"subcampo '{it.get('id')}' es select: emite el valor crudo "
                           "(slug), no su jsonValue", f["id"])
            if it.get("sourceMeta"):
                err("P7", f"subcampo '{it.get('id')}' tiene sourceMeta: no pinta PDF", f["id"])

    # ---------------- P8: condiciones colgadas ----------------
    KEYS = ("conditionalVisibility", "conditionalRequired", "conditionalDisable")

    def check_conds(cv, who, scope):
        c = parse_cv(cv)
        if c is None:
            return
        if c == "INVALID":
            err("P8", "conditionalVisibility no es JSON valido", who)
            return
        for cond in (c.get("conditions") or []):
            fid = cond.get("fieldId", "")
            if fid.startswith(("__rep__", "__sub__")):
                continue
            if fid not in IDS and fid not in scope:
                err("P8", f"condicion apunta a '{fid}', que no existe en su alcance. "
                          "Se ignora en silencio y el campo queda visible", who)

    for _, _, f in F:
        for k in KEYS:
            check_conds(f.get(k), f["id"], set())
        rc = f.get("repeaterConfig") or {}
        for cfg in (rc, rc.get("child") or {}):
            scope = {it["id"] for it in (cfg.get("fields") or [])}
            for it in (cfg.get("fields") or []):
                for k in KEYS:
                    check_conds(it.get(k), f"{f['id']}::{it.get('id')}", scope)

    # ---------------- P13: autoFillConcat ----------------
    for _, _, f in F:
        afc = f.get("autoFillConcat")
        if not afc:
            continue
        conds = [p["condition"]["fieldId"] for p in (afc.get("parts") or []) if p.get("condition")]
        src = set(afc.get("sourceFieldIds") or [])
        faltan = [c for c in conds if c not in src]
        if faltan:
            err("P13", f"autoFillConcat con condiciones sobre {faltan} que no estan en "
                       "sourceFieldIds: no se re-evalua y escribe siempre", f["id"])

    # ---------------- P14: helpers fantasma ----------------
    for _, _, f in F:
        if (f.get("hidden") and f.get("defaultValue")
                and f.get("jsonOutputPath") and not f.get("excludeFromJson")
                and not f.get("autoFillConcat")):
            warn("P14", "helper oculto con defaultValue fijo y sin condicion: escribe "
                        "siempre y puede generar entradas fantasma", f["id"])

    # ---------------- P10: indices de arrays padre ----------------
    # Que nodos son array NO se hardcodea: se deduce del --json-esperado, porque
    # cambia por producto: hay productos donde `personas[].direccion` es un
    # OBJETO y solo `riesgo` / `mediosNotificacion` son arrays.
    # Sin --json-esperado no se puede saber -> no se chequea (antes daba falsos
    # positivos sistematicos sobre `direccion`).
    ARRAY_NODES = set()
    if a.esperado:
        _esp = json.load(open(a.esperado, encoding="utf-8"))

        def _arrays(o, pre=""):
            if isinstance(o, dict):
                for k, v in o.items():
                    if isinstance(v, list):
                        yield k
                    yield from _arrays(v, k)
            elif isinstance(o, list):
                for it in o:
                    yield from _arrays(it, pre)

        ARRAY_NODES = set(_arrays(_esp))

    for _, _, f in F:
        p = f.get("jsonOutputPath")
        if not isinstance(p, str):
            continue
        for nodo in ARRAY_NODES:
            if re.search(r"\.%s\." % re.escape(nodo), p):
                err("P10", f"ruta sin indice en un nodo que el destino define como array: {p}", f["id"])
                break

    # ---------------- P18: select prefillado comparado solo por etiqueta ------
    # Si un select recibe su valor del payload (prefillKey), el valor inyectado
    # es el `jsonValue` de la opcion, no el `label`. Toda condicion que compare
    # ese campo debe cubrir AMBAS formas, o no matchea nada y el formulario
    # aparece vacio. Ver §P18 en platform-rules.md.
    sel_prefill = {}
    for _, _, f in F:
        if f.get("type") in ("select", "radio") and f.get("prefillKey") and f.get("options"):
            labels, jvals = set(), set()
            for o in f["options"]:
                if isinstance(o, dict):
                    if o.get("label") is not None:
                        labels.add(str(o["label"]))
                    jv = o.get("jsonValue", o.get("value"))
                    if jv is not None:
                        jvals.add(str(jv))
            if labels and jvals and labels != jvals:
                sel_prefill[f["id"]] = (labels, jvals)

    # Se junta, por campo dueño y por campo apuntado, el conjunto de valores
    # comparados. Solo es error si aparece una etiqueta y NO aparece tambien su
    # jsonValue: si estan las dos formas, ya esta cubierto.
    comparado = collections.defaultdict(set)
    origen = {}

    def _rec(owner, fid, valor, donde):
        if fid in sel_prefill and valor is not None:
            comparado[(owner, fid)].add(str(valor))
            origen.setdefault((owner, fid), donde)

    for _, _, f in F:
        cv = f.get("conditionalVisibility")
        if isinstance(cv, str):
            try:
                o = json.loads(cv)
            except Exception:
                o = {}
            for c in o.get("conditions", []) or []:
                if c.get("operator") in ("equals", "notEquals"):
                    _rec(f["id"], c.get("fieldId"), c.get("value"), "conditionalVisibility")
        afc = f.get("autoFillConcat")
        if isinstance(afc, dict):
            for part in (afc.get("parts") or []):
                c = part.get("condition") or {}
                if c.get("op") in ("equals", "notEquals"):
                    _rec(f["id"], c.get("fieldId"), c.get("values"), "autoFillConcat")

    for (owner, fid), vals in sorted(comparado.items()):
        labels, jvals = sel_prefill[fid]
        pares = {}
        campo = next((x for _, _, x in F if x["id"] == fid), None)
        for o in (campo.get("options") or []):
            if isinstance(o, dict):
                pares[str(o.get("label"))] = str(o.get("jsonValue", o.get("value")))
        faltan = [v for v in sorted(vals) if v in labels and pares.get(v) not in vals]
        if faltan:
            err("P18", f"{origen[(owner, fid)]} compara '{fid}' solo por etiqueta "
                       f"({', '.join(repr(x) for x in faltan)}) y el campo se prefillea del "
                       f"payload (llega el jsonValue). Agregar tambien la forma en codigo",
                owner)

    # ---------------- cobertura contra el JSON esperado ----------------
    if a.esperado:
        ap_json = json.load(open(a.esperado, encoding="utf-8"))

        def paths(o, pre=""):
            if isinstance(o, dict):
                for k, v in o.items():
                    yield from paths(v, f"{pre}.{k}" if pre else k)
            elif isinstance(o, list):
                for v in o:
                    yield from paths(v, pre + "[]")
            else:
                yield pre

        APP = set(paths(ap_json))
        norm = lambda p: re.sub(r"\[\d+\]", "[]", p)
        N = set()
        for _, _, f in F:
            rc = f.get("repeaterConfig") or {}
            if f.get("type") == "repeater":
                for cfg in (rc, rc.get("child") or {}):
                    if cfg.get("jsonSlotPattern"):
                        b = norm(base_from_pattern(cfg["jsonSlotPattern"]))
                        for it in (cfg.get("fields") or []):
                            if it.get("id"):
                                N.add(b + "." + it["id"])
                continue
            if f.get("excludeFromJson"):
                continue
            p = f.get("jsonOutputPath")
            if isinstance(p, str) and p.strip():
                N.add(norm(p))
        miss, extra = sorted(APP - N), sorted(N - APP)
        print(f"\nCOBERTURA: {len(APP)-len(miss)}/{len(APP)} = "
              f"{round(100*(len(APP)-len(miss))/max(1,len(APP)))}%")
        for m in miss:
            print("   FALTA ", m)
        print(f"   ({len(extra)} rutas que emitimos y no estan en el esperado)")

    # ---------------- salida ----------------
    print()
    for rule, who, msg in ERRORS:
        print(f"ERROR [{rule}] {who}: {msg}")
    for rule, who, msg in WARNS:
        print(f"WARN  [{rule}] {who}: {msg}")
    print(f"\n{len(ERRORS)} ERROR, {len(WARNS)} WARN")
    return 1 if ERRORS else 0


if __name__ == "__main__":
    sys.exit(main())
