---
name: signframe-form-def
description: >
  Construye, edita y valida los JSON de definicion de formularios de Signframe
  que mapean PDFs del INS Costa Rica (Vital 360, Gastos Medicos, Vida Colectiva,
  Vida Universal, Proteccion Crediticia, Fidelidad). Usar SIEMPRE que se pida
  armar, editar, versionar o validar un "form-def", "definicion de formulario" o
  "JSON de Signframe"; cuando se mencione sourceMeta / sourceName / AcroForms /
  jsonSlotPattern / selectJsonValueType / autoFillConcat / repeaterLookup /
  subrepeater; cuando se pase un PDF renombrado del INS con su ficha o matriz de
  mapeo; cuando se pida que un PDF "pinte" o "rellene" sus campos. Tambien para
  diagnosticar: un campo que sale como string, no sale, sale duplicado o cuelga
  de la raiz del JSON; un import de Signframe que pierde campos del PDF o los
  trae con el tipo equivocado; una seccion que se abre vacia y un PDF que sale
  en blanco en ese bloque. Con PDF renombrado + ficha + main de Signframe arma
  un form-def casi terminado.
---

# Signframe Form-Definitions (INS Costa Rica)

Genera y edita los JSON que Signframe consume para (a) dibujar un formulario y
(b) rellenar/"pintar" el PDF del INS. El objetivo es un JSON perfecto: secciones
ordenadas, `sourceMeta` intactos, campos que pintan, anchos de layout coherentes,
y una salida JSON que respete el esquema del cliente.

## Contexto de trabajo

- Usuario: Marcos (Professional Services, Signaturit/Namirial). Espanol argentino
  informal, respuestas directas y ready-to-use.
- Plataforma destino: **Signframe** (NO Lovable).
- Ante ambiguedad: preguntar con opciones cortas, no inventar.
- Versionar incremental (v1 -> v2...), nunca pisar.
- Trabajar SIEMPRE sobre el ultimo archivo que pasa el usuario.

## REGLA DE ORO (leer antes de tocar nada)

Los `id` y `sourceMeta` de los campos que vienen del PDF **NUNCA** se cambian,
renombran ni se les altera el contenido. El render mapea por
`id -> sourceName -> sourceMeta`. Solo se modifican *propiedades*.
Convencion: `id == "field_" + sourceName.lower()`. Los campos nuevos de UI llevan
ids nuevos y NO tienen `sourceMeta`.

Excepcion verificada: un campo **sin `sourceMeta`** se puede renombrar, pero hay
que reemplazar todas sus referencias (`autoFillConcat.sourceFieldIds`, `parts`,
`conditionalVisibility`, `buttonConfig`, `radioGroupFields`, `childrenOrder`).

## REGLA DE PLATA (aprendida a los golpes)

**No suponer sintaxis: copiar de algo que ya funciona en el mismo archivo.**
Cuando algo no anda, comparar el campo roto contra un campo equivalente que si
anda y mirar que propiedad tiene de mas. Asi aparecieron `sourceFieldIds` en
`autoFillConcat` (§P13) y el `jsonSlotPattern` de los repeaters (§P4).

Y antes de dar por buena una regla, chequearla contra `references/platform-rules.md`,
que esta leida del codigo fuente de Signframe.

Corolario: **las reglas de los scripts tambien se verifican.** El linter tenia
`direccion` hardcodeado como nodo array y marcaba errores inexistentes en un
producto donde `personas[].direccion` es un objeto. Si una regla contradice el
JSON de ejemplo del cliente, manda el ejemplo (§P10).

## Entradas ideales (pedirlas si faltan)

1. **PDF renombrado** (y si existe `*_con_labels.pdf`). Pasarlo SIEMPRE por
   `scripts/check_pdf.py` antes de importarlo: un PDF puede verse perfecto en
   Acrobat y aun asi perder campos al importar (`references/etapa0-pdf.md`).
2. **Ficha de configuracion** (xlsx). Hay dos formatos:
   - **Nuevo** (una hoja por nodo JSON, primera hoja `Estructura base JSON`)
     -> leer `references/ficha-nueva.md`. Es el que hay que asumir por defecto.
   - **Viejo** (matriz plana de 22 columnas) -> `references/conventions.md`.
   Ojo con la columna *"Formulario a visualizar"*: filtra que filas aplican.
3. **Main / export de Signframe** — unica fuente valida de `sourceMeta`.
4. **JSON de ejemplo del cliente** — el arbol destino real, para medir cobertura.
5. **Un payload real de salida** — vale mas que cualquier suposicion.

Si la ficha y el JSON de ejemplo del cliente se contradicen, **no elegir**:
listarle las diferencias al cliente y pedir que defina cual manda.

## Procedimiento

1. **Leer `references/platform-rules.md`** (que hace la plataforma en runtime),
   `references/ficha-nueva.md` (como se lee la ficha) y tener a mano
   `references/patterns.md` (cookbook copy-paste). `conventions.md` para el porque.
2. **Anclar en el ground truth**: `_sourcePdf.fieldPositions` del propio JSON.
   Nunca inventar ni "corregir" un sourceName (los typos del PDF van tal cual).
3. **Agrupar segun la matriz** y setear `jsonOutputPath` (§P1). Los campos sin
   slot en destino -> `excludeFromJson: true`.
4. **Cablear los patrones** desde el cookbook.
5. **Validar en loop hasta 0 ERROR**:
   ```
   python3 scripts/validate.py <form-def.json> [--acroforms <acroforms.xlsx>]
   python3 scripts/lint_platform.py <form-def.json> [--json-esperado <ejemplo.json>]
   ```
6. **Versionar y entregar** con un resumen corto y un diff de claves planas que
   confirme que no se toco nada fuera de lo pedido.

## Modo B: revisar un form-def existente contra la ficha

Cuando el form-def ya existe y el usuario pega **una hoja de la ficha por
mensaje** y pregunta "esta ok?":

1. Antes de la hoja 1, correr los dos scripts y avisar los problemas
   transversales: casillas que pintan con `"X"` sobre widgets `/Btn`, labels sin
   tildes que quedaron del importador ("Informacion", "Dolares", "C10.000.000"),
   selects prellenados comparados solo por etiqueta (§P18), `prefillMode:"api"`
   que quedo de una version vieja, estructura de secciones distinta a la
   canonica y falta del campo `signature`.
2. Por hoja, responder con una tabla corta `Ficha | Form | Estado`
   (✅ coincide · ❌ corregir · ⚠️ matiz · ➖ sobra, se oculta), solo lo
   accionable, y cerrar con las decisiones que faltan en formato A/B (max 3).
3. **No generar un archivo por hoja**: acumular y sacar una version cuando el
   usuario diga "dale" o cuando se junten varios cambios. Si el archivo que
   paso el usuario ya dice `"version": "..._v17"`, la proxima es v18.
4. Si el usuario contesta con una letra o una palabra ("b", "si", "A"), aplicar
   y seguir sin repreguntar.

Orden de las hojas y que mirar en cada una:

- **encabezado** — 13 o 14 campos (puede no estar `metodoEnvioFormulario`),
  ocultos, `readOnly`, prellenados desde su misma ruta, sin `defaultValue`.
  `conozcaClienteActualizado` **tiene que ser `type:"boolean"`**.
- **datosGenerales** — `lugar`, `fechaCreacion` (GETDATE -> `defaultValue:"today"`,
  editable), `observaciones`. Los dia/mes/ano que pintan el PDF salen por
  `substring` de **DD/MM/AAAA** (`0-2`, `3-5`, `6-10`); si estan en `0-4/5-7/8-10`
  estan mal (M9). Textos legales -> `instructions` + 1 checkbox maestro (§M7).
  Campos que el PDF tiene y la ficha no (hora, tipo de tramite) -> ocultos,
  readOnly, alimentados desde el encabezado.
- **intermediario** — 5 campos prellenados y readOnly; el tipo de identificacion
  visible si la ficha dice "Disabled / Visible / Dato Prellenado".
- **polizaMadre** — regla "si no se remite la poliza, editables y no
  obligatorios": nada de `readOnly` fijo. Tipo de identificacion del tomador con
  catalogo **juridico** y ojo con la ruta (`codigoTipoIdentificacionTomador`).
- **datosAdicionales** — reglas "si elige SI mostrar la leyenda X" con un campo
  `type:"label"` (texto en `defaultValue`) + `conditionalVisibility`.
- **personas** — ver §Personas y §Estructura estandar mas abajo.
- **riesgo** — repeater o escalar; dos repeaters sobre el mismo array comparten
  indice (referencia 1 y empleo 1 caen en `riesgo[0]`): confirmarlo con el
  cliente. Los Si/No Boolean -> select `excludeFromJson` + helper `boolean`.
- **direccion** — objeto o array segun el producto (mirar el ejemplo); cascada
  con `parentFieldId`/`grandParentFieldId` **de la misma persona** (§P17) y 3
  helpers de descripcion (§P11).
- **mediosNotificacion** — medio + texto de 50 que aparece y se vuelve
  obligatorio recien cuando hay medio elegido.

Separar siempre los pendientes: **del cliente** (contradicciones ficha vs
ejemplo, codigos de catalogo, semantica de arrays) y **del usuario** (reimportar
el PDF, arreglar widgets con el tipo cruzado, ajustar el `rect` de la firma).

Si la ficha y el JSON de ejemplo se contradicen, **no elegir**: listar las
diferencias para el cliente. Casos ya vistos: `codigoEstadoCivil` `1` vs
`"SOL"`, `codigoParentesco` `Conyuge` vs `"CON"`, `codigoFormaPago` `4` vs
`"MENSUAL"`, `JRD` (ficha) vs `PJR` (catalogo), `codigoProvincia` `"01"` vs `"1"`.

Ojo con la columna **Regla** de la ficha: `No aplica Formulario XXXX` saca esa
fila del producto aunque la columna Obligatorio diga `Both`.

## Estructura estandar de secciones (igual en TODOS los productos)

```
1. Datos Generales
   - Datos del Sistema (oculto)      <- encabezado + helpers, CV NEVER_EXISTS
   - Datos de la Poliza Madre
   - Datos del Asesor
   - Informacion de la Solicitud     <- lugar, hora, fecha, observaciones
   - Informacion adicional           (si el producto la tiene)
2. Datos de la Persona / del Tomador / del Asegurado
   - Datos <persona> / Contacto y Ubicacion / Preferencias de Notificacion
3. Dependientes            (si aplica)
4. Informacion del Riesgo  (si aplica)
5. Beneficiarios           (si aplica)
6. Firmas (oculto)
7. Declaraciones y Autorizacion      <- SIEMPRE al final
```

Las declaraciones van al final aunque la ficha las liste dentro de Datos
Generales: el usuario acepta despues de revisar todo.

## Reglas de UI acordadas

- Tipo de identificacion y numero de identificacion: `half` + `half`. Los 4
  nombres: `quarter` cada uno. Nombre completo: `full`. Fechas: `fit`.
  Telefonos y cantidades: `quarter`. Provincia/canton/distrito: `third`.
- **Nombre completo**: `readOnly: true`, **sin `prefillKey` ni `prefillMode`**,
  llenado solo por `autoFillConcat` de los 4 nombres (queda bloqueado).
  Excepcion: si esa persona no tiene los 4 nombres en la ficha (Tomador,
  "Nombre completo o razon social"), queda editable y prellenado — bloquearlo
  sin prellenado lo dejaria siempre vacio.
- **Telefonos: uno solo visible.** Si el PDF tiene casilleros de telefono y de
  celular pero la ficha pide un unico "Telefono/Celular", el visible es uno
  (`telefonoMovil`) y el otro casillero queda oculto copiandolo por
  `autoFillConcat`. Varios telefonos solo si la ficha los lista por separado.
- **Decir "Sexo", no "Genero"** en todo lo visible (label, `radioGroupLabel`,
  "Descripcion del sexo"). Las rutas siguen siendo `codigoGenero` /
  `descripcionGenero`: no se tocan.
- **Lo que no esta en la ficha se oculta, no se borra** (primas, poliza
  individual, modalidad de vigencia, clausula, "notificar a"): el casillero del
  PDF sale vacio y el campo queda disponible. Avisarlo en la entrega.
- `prefillMode: "optional"` SIEMPRE.
- Tildes y enes: corregir label, opciones y las condiciones que los comparan,
  todo junto.

## Tipos de dato y catalogos del INS

- La ficha dice Boolean -> `type:"boolean"`. Un select Si/No que debe salir
  `true`/`false`: select visible `excludeFromJson` + helper oculto
  `type:"boolean"` con `autoFillConcat` (`"true"` condicionado al Si). Un radio
  nunca tipa (§P2).
- Casillas del PDF: widget `/Btn` -> pintar con `true` (booleano). `"X"` solo si
  el widget es `/Tx`.
- Todo select prellenado compara en **sus dos formas**, etiqueta y `jsonValue`
  (§P18); si un bloque cubre varios codigos (ASG/DME/DMA), `logic:"or"` con
  todas las variantes.
- Codigos (del xlsx de catalogos, no inventar):
  - Identificacion **fisica**: Fisica `0`, DIMEX `6`, Pasaporte `9`, DIDI `12`
    (+ `Otro` si el PDF tiene la casilla).
  - Identificacion **juridica**: Juridica Nacional `3`, Gobierno `2`,
    Institucion autonoma `4`, Juridica extranjera `7`.
  - Estado civil `1..9` · Moneda `CRC`/`USD` · Forma de pago `1..6` ·
    Tramite `EMI`/`VAR`/`CAN`/`INC` · Persona `ASG/DME/DMA/TOM/BNF/PJR`.

## Personas: como decidir la estructura

- **Un tipo de persona por documento** (el request trae `codigoTipo`): todo en
  `personas[0]`, subsecciones por grupo de codigo (ASG/DME/DMA vs TOM vs
  JRD/PJR). `codigoTipo` oculto, readOnly, prellenado, **sin `defaultValue`**.
- **Varias personas fijas** (la ficha lista Asegurado y Tomador siempre):
  indices fijos `personas[0]` y `personas[1]`, `codigoTipo` oculto con
  `defaultValue` (no hay riesgo de fantasma porque siempre existen).
- **Beneficiarios / dependientes agregables**: subsecciones fijas con botones
  agregar/quitar y `codigoTipo` por `autoFillConcat` condicionado al nombre
  (nunca `defaultValue`, §P14). **No se pueden hacer con repeater**: un repeater
  escribe desde `personas[0]` y pisaria a la persona principal.
- Cada persona puede tener su `direccion` y sus `mediosNotificacion`.

## Firmas (§P20)

La seccion `Firmas` va oculta y lleva el/los campos `type:"signature"`:

```json
{ "type": "signature", "hidden": true, "sharedValue": true, "excludeFromJson": true,
  "prefillKey": "encabezado.correoElectronico", "prefillMode": "optional",
  "signatureSignerNamePrefillKey": "encabezado.nombreCompletoCliente",
  "signatureCcPrefillKey": "datosFormulario.datosGenerales.intermediario.correoElectronico",
  "signatureCcNamesPrefillKey": "datosFormulario.datosGenerales.intermediario.nombre",
  "signatureSendCopy": true, "visibleInReview": true,
  "sourceMeta": { "sourceName": null, "sourceType": "signature", "page": 3,
                  "rect": { "x": 0, "y": 0, "width": 180, "height": 60 } } }
```

- Una firma por firmante posible; si el PDF tiene lugar de firma del tomador y
  del asegurado van **dos**, cada una con `conditionalVisibility` por grupo de
  `codigoTipo`.
- El `rect` va en **minusculas** y con origen arriba-izquierda: calcularlo
  aproximado desde el casillero de identificacion de la firma y avisar que se
  ajusta arrastrando en el editor.
- Los casilleros de texto al lado de la firma (identificacion, representante
  legal) se copian **condicionados al grupo de persona**, con `codigoTipo` en
  `sourceFieldIds` (§P13); si no, se pintan los dos bloques a la vez.


## Las trampas que mas cuestan (resumen de platform-rules.md)

| Sintoma | Causa | §  |
|---|---|---|
| Clave con un id numerico colgando de la raiz | repeater sin `jsonSlotPattern` | P4 |
| `"[object Object]"` en el JSON | repeater con `jsonOutputPath` seteado | P4 |
| Array con `null` en la posicion 0 | patron con `{i1}` en vez de `{i}`/`{i0}` | P4 |
| Un booleano sale `"true"` con comillas | es un radio; solo `type:"boolean"` tipa | P2 |
| Un numero sale con comillas | el campo es `type:"text"` | P3 |
| Un codigo de catalogo sale string y el destino lo quiere numerico | falta `selectJsonValueType:"number"` | P3 |
| Un campo aparece donde no deberia | condicion apuntando a un id inexistente (se ignora) | P8 |
| Un bloque anidado aparece en todos los items | el subrepeater no se puede condicionar | P5 |
| Un select dentro de un repeater emite el slug | falta `options` / `selectJsonValueType` en el subcampo | P6 |
| Un helper escribe siempre | falta el fieldId de la condicion en `sourceFieldIds` | P13 |
| Entradas fantasma en `personas[]` | helper oculto con `defaultValue` fijo | P14 |
| Un nodo sale array y objeto a la vez | un campo suelto escribe dentro de un nodo de repeater | P9 |
| Un repeater "apagado" igual emite | `excludeFromJson` no apaga repeaters | P4 |
| Varias filas de la ficha con la misma ruta JSON | son `Comentario Informativo`: un solo checkbox maestro | M7 |
| Un campo de la ficha no se dibuja | `Obligatorio: JSON` / `Visualizacion: No Aplica` | M4, M5 |
| Una seccion entera aparece vacia y el PDF sale en blanco ahi | select prefillado: la condicion compara la etiqueta y llega el `jsonValue` | P18 |
| El main baja con un campo menos que el PDF | widget sin `/FT` propio: el importador lo saltea | E1 |
| Un checkbox importa como `multiselect` | en el PDF es `/Ch` y no `/Btn` | E2 |
| Un checkbox importa bien pero nunca se marca | le falta el `/AP/N`, o el estado no es `Si` | E2 |
| Reimportar el PDF no agrega el campo que faltaba | `_sourcePdf` se arma al importar el PDF, no al guardar el JSON | P19 |
| Una seccion aparece vacia y el PDF sale en blanco ahi | select prefillado comparado solo por etiqueta | P18 |
| El dia y el mes salen mal en el PDF | substring en formato ISO sobre una fecha DD/MM/AAAA | M9 |
| Una casilla del PDF nunca se marca | pinta con `"X"` y el widget es `/Btn` | E2 |
| Un campo calculado (edad) siempre vacio | falta `autoFillConcat` con `dateRef today` + `diffYears` | P16 |
| Una `descripcionX` siempre vacia | falta el helper con `valueSource:"visible"` | P11 |
| Cascada canton/distrito que no filtra | `parentFieldId`/`grandParentFieldId` de otra persona | P17 |

## Anchos de layout (`field.width`)

`"full" | "three-quarters" | "two-thirds" | "half" | "third" | "quarter" | "fit" | null`.
NO confundir con `sourceMeta.rect.Width`, que es la caja del PDF y no se toca.
Los anchos por tipo de campo estan en §Reglas de UI acordadas.

## Checklist de validacion

### Convencion del form-def (`validate.py`)
1. Todos los `sourceName` == AcroForms reales.
2. `id == "field_"+sourceName` en todos los campos con sourceMeta.
3. 0 ids duplicados.
4. Todos los campos del PDF pintan, salvo excepciones explicitas.
5. Checkboxes que pintan: `checkedPdfValue` correcto.
6. `conditionalVisibility` = string JSON con `fieldId` prefijado `field_`
   (**excepto dentro de repeaters**, donde va el id pelado del subcampo hermano).
7. `autoFillConcat` op:equals usa la clave `values`.

### El PDF, antes de importar (`check_pdf.py`)
0. 0 widgets sin `/FT` propio, 0 nombres sucios, 0 `/V` heredados, checkboxes
   con `/AP` y `/DA`. Un campo mal creado NO se arregla del lado del JSON.

### Runtime (`lint_platform.py`)
8. `jsonOutputPath` presente y coincidente con `salidaJSON`.
9. Repeaters sin `jsonOutputPath`, con `jsonSlotPattern` valido.
10. Ningun campo suelto escribiendo dentro de un nodo de repeater.
11. Ninguna condicion apuntando a un id inexistente.
12. `sourceFieldIds` cubre los fieldId de las condiciones de `autoFillConcat`.
13. Indices de arrays padre escritos a mano (`riesgo[0]`, `personas[0]`).
14. Cobertura contra el JSON de ejemplo del cliente.
15. Todo select con `prefillKey` comparado en sus dos formas (etiqueta y
    `jsonValue`). El `notEquals` se reescribe como `equals`, no se duplica.

## Referencias

- `references/platform-rules.md` — **que hace Signframe en runtime** (leido del
  codigo fuente). Empezar por aca cuando algo no sale como se espera.
- `references/ficha-nueva.md` — como se lee la ficha de configuracion actual
  (una hoja por nodo JSON) y el bloque fijo de encabezado.
- `references/etapa0-pdf.md` — que necesita el importador del AcroForm, y por
  que un PDF que se ve bien pierde campos igual.
- `references/conventions.md` — convenciones completas §1–§24.
- `references/patterns.md` — cookbook copy-paste.
- `references/examples/` — form-def(s) de oro.
- `scripts/validate.py` — validador de la convencion del form-def.
- `scripts/lint_platform.py` — linter de las reglas de runtime.
- `scripts/check_pdf.py` — chequeo estructural del PDF antes de importarlo.
