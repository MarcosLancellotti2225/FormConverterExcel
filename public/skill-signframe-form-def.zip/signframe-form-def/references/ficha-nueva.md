# Ficha de configuracion — formato nuevo (una hoja por nodo JSON)

Reemplaza al formato de matriz plana. Se reconoce porque la primera hoja se llama
**`Estructura base JSON`** y despues hay **una hoja por cada nodo** del JSON
destino (`encabezado`, `datosGenerales`, `polizaMadre`, `personas`, `riesgo`…).

Ejemplo de referencia: `Ficha_de_configuración_-_Fidelidad.xlsx` (12 hojas).

---

## §M1 — Hoja `Estructura base JSON`

Es el indice del formulario. Tres columnas:

| Estructura del JSON | Pasos del formulario WEB | Secciones del Formulario WEB |
|---|---|---|
| `encabezado` | No aplica | No aplica |
| `datosFormulario.datosGenerales` | Datos Generales | Información de la solicitud / Declaraciones |
| `datosFormulario.datosGenerales.intermediario` | Información de Póliza | Datos del Asesor |
| `datosFormulario.personas[]` | Datos del Tomador | Datos Tomador / Contacto y ubicación |
|  | Datos del Asegurado | Datos Asegurado / Contacto y ubicación |
| `datosFormulario.personas.riesgo[]` | Información del riesgo | Información del riesgo / Coberturas Básicas |

Como leerla:

- **Pasos** = secciones de primer nivel del form-def.
- **Secciones** = subsecciones, separadas por `/`.
- **`No aplica`** en las dos columnas = el nodo no se dibuja, va solo al JSON.
- Un nodo con **varias filas y la primera columna vacia** significa que ese nodo
  se **instancia varias veces**, una por paso. En Fidelidad `personas[]` sale
  cuatro veces: Tomador, Asegurado, Dependiente, Beneficiario. Cada instancia es
  un indice distinto de `personas[]` en el form-def.
- La notacion de arreglo ya viene en la ruta (`personas[]`, `riesgo[]`).

---

## §M2 — Hojas de nodo: las 14 columnas

Todas las hojas de nodo comparten cabecera:

| # | Columna | Para que sirve |
|---|---|---|
| 0 | Pasos Formulario | seccion del form-def (o `JSON`) |
| 1 | Sección | subseccion del form-def (o `JSON`) |
| 2 | Nombre en PDF | etiqueta impresa en el PDF, referencia visual |
| 3 | Nombre del campo en formulario | **`label`** del campo |
| 4 | Tipo de dato | ver §M3 |
| 5 | Valor | catalogo, valor fijo, o una fila por opcion |
| 6 | Regla | visibilidad condicional en prosa |
| 7 | Obligatorio | ver §M4 |
| 8 | Formulario a visualizar | filtro por producto (`TODOS` o el codigo) |
| 9 | Visualización en Formularios | ver §M5 |
| 10 | Observaciones | maxLength, formato, patron |
| 11 | Nombre de la sección del JSON | nodo padre |
| 12 | **Nombre del campo en el JSON** | **`jsonOutputPath`** |
| 13 | **Nombre interno del campo en PDF** | **`sourceName`** del AcroForm |

Las dos ultimas son las que hacen el trabajo: la 12 da la ruta de salida y la 13
el `sourceName` que hay que cruzar contra `_sourcePdf.fieldPositions`.

Si la columna 12 trae **dos rutas separadas por coma**, es un par
codigo + descripcion: hacen falta dos campos, el select y un helper de descripcion.

---

## §M3 — Columna `Tipo de dato`

| Valor en la ficha | `type` en el form-def |
|---|---|
| Texto | `text` |
| Numérico | `number` |
| Numérico/Porcentual | `number` |
| Fecha | `date` |
| Combo | `select` |
| Radio/Combo | `radio` (o `select`, segun cantidad de opciones) |
| Boolean | `boolean` |
| Tabla | ver §M6 |
| Checkbox / Check box | `checkbox` |
| Comentario Informativo | texto que se muestra, no recoge dato (§M7) |

Ojo: `Numérico` **tiene que** salir como `type: "number"`, y un `Combo` cuyo valor
sea un codigo numerico necesita `selectJsonValueType: "number"` (platform-rules §P3).

---

## §M4 — Columna `Obligatorio` (define el destino del campo)

Es la columna mas importante y su nombre enga&ntilde;a: no dice solo si es requerido,
dice **a donde va el campo**.

| Valor | Significado |
|---|---|
| `JSON` | solo salida JSON. No se dibuja ni pinta PDF. Las columnas 0 y 1 tambien dicen `JSON` |
| `WEB` | solo formulario. No va al JSON -> `excludeFromJson: true` |
| `Both` | va al JSON y al PDF |
| vacio | no obligatorio; el destino se deduce de las columnas 0/1 y 13 |
| `Al menos una selección` | grupo donde al menos una opcion debe elegirse |

Un campo con `Obligatorio: JSON` es un helper oculto con `prefillMode: "api"`.

---

## §M5 — Columna `Visualización en Formularios`

| Valor | Como se traduce |
|---|---|
| `editable / input del usuario / visible` | campo normal editable |
| `editable / Dato Prellenado / visible` | editable pero prellenado -> `prefillMode: "api"` |
| `Disabled / Visible` | se muestra en solo lectura -> `readOnly: true` |
| `editable / visible` | editable, sin prellenado |
| `No Aplica` | no se dibuja -> `hidden: true` |

---

## §M6 — `Tipo de dato: Tabla`

La columna `Valor` describe las columnas de la tabla y cuantas filas admite:

```
Fecha / Porcentaje % (se deben de permitir al menos 3 filas para reportar
Fecha / Sistólica / Distólica (se deben de permitir al menos 3 filas para reportar
```

Una tabla se resuelve con un repeater, **pero antes hay que verificar donde vive**:
si la tabla cuelga de un nodo que ya es un arreglo, aplica el limite de un solo
subrepeater por listado y la imposibilidad de condicionarlo
(platform-rules §P5). En ese caso hay que negociar la estructura con el cliente.

---

## §M7 — `Comentario Informativo`

Filas cuyo `Tipo de dato` es `Comentario Informativo` son **textos que se muestran
al usuario pero no recogen un check propio**. Varias filas seguidas suelen
compartir la misma ruta JSON (ej. todas las declaraciones legales apuntan a
`personas[].indicadorClienteDaConsentimiento`).

Se resuelven con **un solo checkbox maestro** que escribe la ruta, y los textos
como campos ocultos o labels. No crear un campo con salida JSON por cada fila:
se pisan entre si.

---

## §M8 — El encabezado es un bloque fijo del proyecto

Verificado identico en GMC y Fidelidad: **los mismos 14 campos, en el mismo
orden**. No cambia por formulario.

```
codigoTipoFormulario             Texto     api
descripcionTipoFormulario        Texto     api
codigoTipoTramite                Texto     api
descripcionTipoTramite           Texto     api
identificadorTransaccionInterno  Texto     api
correoElectronico                Texto     api
codigoProducto                   Texto     api
descripcionProducto              Texto     api
nombreCompletoCliente            Texto     api
identificadorArchivo             Texto     lo completa el backend de Namirial
conozcaClienteActualizado        Boolean   api   -> type: "boolean"
sedeAdministradora               Texto     api
descripcionSedeAdministradora    Texto     api
metodoEnvioFormulario            Combo     api   -> select ("eMail" / "Whatsapp" / "URL o Link")
```

Todos con `Visualización: No Aplica` -> `hidden: true`, sin `sourceMeta`, con
`jsonOutputPath = "encabezado.<campo>"` y `prefillMode: "api"`.

`identificadorArchivo` no se dibuja ni se mapea: lo genera Namirial al crear el
documento. Excluirlo del calculo de cobertura.

El orden de las claves raiz lo fuerza la plataforma (platform-rules §P12), asi que
no hace falta ubicar la seccion al principio.

---

## §M9 — Procedimiento con esta ficha

1. Leer `Estructura base JSON` -> armar el esqueleto de secciones y subsecciones,
   y detectar los nodos que se instancian varias veces (§M1).
2. Por cada hoja de nodo, filtrar por `Formulario a visualizar`.
3. Separar las filas por `Obligatorio` (§M4): `JSON` -> helpers ocultos,
   `WEB` -> `excludeFromJson`, `Both` -> campo normal.
4. Cruzar la columna 13 (`Nombre interno del campo en PDF`) contra
   `_sourcePdf.fieldPositions`. Lo que no matchea, avisarlo: o falta en el PDF o
   el nombre esta mal.
5. Traducir `Tipo de dato` (§M3) y `Visualización` (§M5).
6. Pasar las reglas de la columna 6 a `conditionalVisibility`, respetando el
   alcance (platform-rules §P8).
7. Correr `validate.py` y `lint_platform.py` hasta 0 ERROR.

---

## §M10 — Que confirmar con el cliente antes de arrancar

- Los combos con `Valor: "Ver Catálogo"` no traen el catalogo en la ficha: pedirlo.
- La hoja `JSON Generado` suele traer el ejemplo de salida completo: sirve como
  referencia de cobertura, pero **verificar que este alineado con la ficha**. En
  GMC la ficha y el JSON de ejemplo se contradecian en ~40 nombres de campo.
- Si la ficha y el JSON de ejemplo difieren, **no elegir**: listarle las
  diferencias al cliente y pedir que defina cual manda.


---

## Celdas en verde: campos adicionales por tipo de persona

El cliente marca **con relleno verde** las filas que son adicionales al estandar
para cada tipo de persona. No se ve leyendo solo los valores: hay que leer el
`fill` de la celda (`openpyxl` sin `read_only`, `cell.fill.start_color.rgb`).

Suelen ser pocas filas por instancia: ocupacion o profesion y los telefonos en la
instancia del asegurado, la relacion con el asegurado en la del tomador, fecha de
constitucion e interes en la del beneficiario juridico.

Verde oscuro (`FF00B050`) es el encabezado de las columnas L, M y N; verde claro
(`FF92D050`) son los campos adicionales. Solo el claro marca contenido.

## La hoja `personas` trae el bloque repetido, una vez por tipo

Hay que partirla por instancia antes de cruzar nada: las filas se repiten con
los mismos nombres de campo y solo cambia la columna A/B (`Datos Persona`,
`Datos Tomador`, `Datos Beneficiario`) y el valor de `codigoTipo`. Al resolver
que `sourceName` corresponde a cada fila, filtrar por el prefijo de la instancia
(`asg_`/`pjr_`, `tom_`, `bnf1_`/`bnf2_`/`bnfpj_`) o se mezclan entre si.

## Defectos habituales de la ficha

- La columna de ruta JSON puede traer **mas de una ruta separadas por coma**.
  Hay que splitear antes de matchear, o la fila da falso negativo.
- Puede venir **truncada** a mitad de una ruta (visto: `...codigoGenero,
  datosFormulario` y ahi cortaba). Se reporta al cliente, no se adivina.
- Filas sin ruta y sin tipo de dato son `Comentario Informativo` o marcadores de
  seccion: no son campos.
