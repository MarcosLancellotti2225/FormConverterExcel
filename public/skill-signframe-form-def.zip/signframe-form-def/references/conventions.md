# Convenciones Form-Definitions Signframe (INS Costa Rica)

Detalle completo. Leer entero antes de armar o editar un form-def.

## Tabla de contenido
- §1 Regla de oro — campos que pintan el PDF
- §2 Pintado del PDF — readOnly y checkboxes
- §3 Estructura estandar del form (secciones/subsecciones)
- §4 Esquema de campo (propiedades clave)
- §5 Radios "desdoblados"
- §6 conditionalVisibility / conditionalRequired (string JSON)
- §7 autoFillConcat (helpers ocultos que pintan)
- §8 Formato numerico (Costa Rica)
- §9 Repeaters + agregadores
- §10 repeaterLookup (preexistencias)
- §11 Notificacion
- §12 Fecha partida (dia/mes/ano)
- §13 Observaciones multilinea
- §14 Paths del JSON destino
- §15 Catalogos / codigos INS

---

## §1 Regla de oro — campos que pintan el PDF

Los `id` y `sourceMeta` de los campos del PDF NUNCA se cambian, renombran ni se
les altera el contenido. El render mapea por `id -> sourceName -> sourceMeta`. Si
se altera cualquiera, el render no encuentra el campo y **no lo dibuja**.

- Solo se pueden modificar **propiedades** (hidden, readOnly, autoFillConcat,
  conditionalVisibility, label, width, etc.).
- Convencion verificada: `id == "field_" + sourceName` (o `field_field_*` segun
  el renombrado; respetar el que venga).
- Los campos nuevos de UI (selects, radios desdoblados, repeaters, helpers de
  concatenacion) llevan ids nuevos y NO tienen `sourceMeta`.
- Validar siempre tras cada edicion (ver checklist §16 en SKILL.md / validate.py).

## §2 Pintado del PDF — readOnly y checkboxes

- Los campos que pintan deben quedar rellenables: `readOnly: false`. (Pueden estar
  `hidden: true` y aun asi pintar, pero readOnly los bloquea.)
- Checkboxes que pintan: en el autorelleno el valor de la parte de texto debe ser
  **`true` (booleano)**, NO `"X"`. Con `"X"` no pintan. Normalizar `"x"` -> `true`.
- Los checkboxes visibles sin `sourceMeta` (no pintan directo, lo hace su helper)
  pueden conservar `checkedPdfValue: "X"`.

## §3 Estructura estandar del form (secciones = pasos, subsecciones = seccion de matriz)

Orden tipico (Vida Colectiva / Universal):

1. Datos Generales — Datos del Sistema (oculto) · Informacion de la Solicitud ·
   Datos del Asesor · Preferencias de Notificacion
2. Datos del Tomador — Datos del Tomador · Contacto y Ubicacion
3. Datos del Grupo a Asegurar (una sola seccion) — Tipo del Grupo · Suma a
   Asegurar · Cantidad de Miembros
4. Coberturas del Seguro — Coberturas Basicas · Coberturas Adicionales
5. Condiciones Generales Modificables
6. Declaraciones Legales — Declaraciones Legales · Aceptacion de terminos y
   consentimiento

Notas:
- "Datos del Grupo a Asegurar" va unificado (no separar VUVC / VU en secciones).
- Cada `section` lleva `subsections[]` y `childrenOrder`.
- Subseccion de sistema: titulo "Datos del Sistema (oculto)", oculta con NEVER (§6).

## §4 Esquema de campo (propiedades clave)

```jsonc
{
  "id": "field_<sourceName | nuevo>",
  "type": "text|number|date|select|radio|checkbox|textarea|repeater|signature",
  "label": "...",
  "required": false,
  "readOnly": false,
  "hidden": null,              // null = visible; true = oculto
  "width": "full|half",
  "options": null,             // o [{label,pdfValue,jsonValue,parentValues}]
  "optionsLayout": "horizontal",
  "sourceMeta": null,          // SOLO en campos del PDF; NO TOCAR
  "prefillMode": "optional",
  "prefillKey": "datosFormulario...",
  "salidaJSON": "datosFormulario...",
  "jsonOutputPath": "datosFormulario...",
  "excludeFromJson": false,
  "conditionalVisibility": null,   // string JSON serializado (ver §6)
  "conditionalRequired": null,
  "autoFillConcat": null,          // ver §7
  "checkedPdfValue": null,         // checkbox
  "checkedJsonValue": null,
  "jsonNumberFormat": null,        // ver §8
  "validationPattern": null,
  "repeaterConfig": null           // ver §9
}
```

## §5 Radios "desdoblados" (un campo por opcion)

Todo grupo de opciones (Si/No, tipo de grupo, quien paga, suma, etc.) va como
campos separados, NO como array `options` hardcodeado, para poder darles
visibilidad/condiciones desde Signframe.

```jsonc
{
  "id": "field_pago_prima_tomador",
  "type": "radio",
  "label": "Tomador del Seguro (Modalidad No Contributiva)",
  "radioGroupLabel": "¿Quien paga la prima de la poliza?",
  "radioGroupFields": ["field_pago_prima_asegurado"],  // los OTROS del grupo
  "salidaJSON": "datosFormulario.datosGenerales.polizaMadre.modalidad",
  "jsonValue": "Tomador del Seguro (Modalidad No Contributiva)",
  "pdfValue": "X",
  "width": "half"
}
```
- `order` explicito (1,2,3...), nunca 0 (Signframe los apila).
- Si los ids `_si`/`_no` ya existen como helpers del PDF, usar sufijo distinto para
  los visibles (ej. `_sel_si`/`_sel_no`).
- Las `conditionalVisibility` que dependian del combo viejo deben repuntarse a la
  opcion concreta (ej. al campo "Si").

## §6 conditionalVisibility / conditionalRequired — STRING JSON

Siempre string serializado, nunca objeto. `fieldId` con prefijo `field_`.

```jsonc
"conditionalVisibility": "{\"logic\":\"and\",\"conditions\":[{\"fieldId\":\"field_seguro_ant_si\",\"operator\":\"not_empty\"}]}"
```
Operadores: `not_empty`, `empty`, `equals` (con `"value"`).

Seccion/subseccion siempre oculta (NEVER):
```jsonc
"conditionalVisibility": "{\"logic\":\"and\",\"conditions\":[{\"fieldId\":\"field_NEVER_EXISTS\",\"operator\":\"not_empty\"}]}"
```

## §7 autoFillConcat — helpers ocultos que pintan el PDF

```jsonc
"autoFillConcat": { "sourceFieldIds": [...], "separator": " ", "parts": [ ... ] }
```

Patrones de `parts`:

- Pintar "X" si un radio esta marcado (checkbox PDF):
  ```jsonc
  {"kind":"text","value":true,"condition":{"fieldId":"field_x","op":"notEmpty"}}
  ```
  (checkbox que pinta: `value: true`, no "X".)

- Pintar "X" si un select == valor (por label):
  ```jsonc
  {"kind":"text","value":true,"condition":{"fieldId":"field_moneda","op":"equals","values":"Colones"}}
  ```
  (`op:"equals"` usa la clave `values`, con s.)

- Copiar el valor de otro campo:
  ```jsonc
  {"kind":"field","fieldId":"field_tom_pais"}
  ```

- Substring (cortar texto) — fecha (YYYY-MM-DD) u observaciones multilinea:
  ```jsonc
  {"kind":"field","fieldId":"field_fecha","transforms":[{"kind":"substring","start":8,"end":10}]}
  ```
  Correcto: `transforms:[{kind:"substring", start, end}]` (plural + kind).
  NO usar `transform:{op:"substring"}` (sintaxis vieja, repite el texto completo).

- Concatenar varios campos (notificacion: medio + dato):
  ```jsonc
  "separator":" - ",
  "parts":[{"kind":"field","fieldId":"field_notif_medio_select"},{"kind":"field","fieldId":"field_notif_dato"}]
  ```

- Agregar columnas de un repeater (ver §9).
- Lookup en repeater (preexistencias, ver §10).

## §8 Formato numerico (Costa Rica)

- Montos (suma asegurada, niveles, fondos, ahorro): miles `.`, decimales `,`, 2 dec.
  ```jsonc
  "jsonNumberFormat":"#.##0,00", "thousandsSeparator":".", "decimalSeparator":",", "decimalPlaces":2
  ```
- Enteros con miles (cantidad de empleados): miles `.`, sin decimales.
  ```jsonc
  "jsonNumberFormat":"#.##0", "thousandsSeparator":".", "decimalSeparator":null, "decimalPlaces":0
  ```
- Porcentajes no autocalculados (hombres, mujeres): 2 enteros + 2 decimales.
  ```jsonc
  "jsonNumberFormat":"00.00", "decimalSeparator":",", "decimalPlaces":2, "maxLength":5
  ```
  El porcentaje autocalculado (miembros a asegurar) NO se toca.

## §9 Repeaters (listado de personas) + agregadores

Patron para "¿quien o quienes...?" (intervenciones, consultas medicas, diagnostico,
cambios de salud, embarazo). Flujo: radio Si/No -> al elegir Si se muestra el
repeater -> cada campo del PDF se rellena agregando una columna del repeater.

Repeater:
```jsonc
{
  "id":"field_<timestamp>",
  "type":"repeater",
  "sharedValue":true,
  "hidden":null,                     // null para que se muestre; true lo oculta
  "conditionalVisibility":"{...field_<pregunta>si not_empty...}",
  "repeaterConfig":{
    "itemLabel":"Persona","itemLabelPlural":"Personas","addButtonLabel":"Agregar Personas",
    "minItems":1,"maxItems":4,
    "fields":[ /* sub-campos */ ],
    "child":null,"slotMappings":[],"overflow":null,"overflowThreshold":4
  }
}
```

Sub-campo (id propio, sin sourceMeta), puede tener conditionalVisibility/Required
referenciando otro sub-campo del mismo item:
```jsonc
{
  "id":"embarazo_metodo_especifique","type":"text","required":false,
  "conditionalVisibility":"{\"logic\":\"and\",\"conditions\":[{\"fieldId\":\"embarazo_tipo_reproduccion\",\"operator\":\"equals\",\"value\":\"asistida\"}]}",
  "conditionalRequired":"{...mismo...}"
}
```

Agregador (campo del PDF que pinta los datos del repeater): `hidden:true`,
`readOnly:false`, y:
```jsonc
"autoFillConcat":{
  "sourceFieldIds":[],"separator":" ",
  "parts":[{
    "kind":"repeaterAggregate",
    "repeaterFieldId":"field_<repeater>",
    "scope":"parent",
    "subFieldIds":["sub_a"],
    "separator":", ",
    "group":true,
    "groupFieldIds":["sub_a","sub_b"],
    "groupSeparator":": ",
    "subFieldLabels":{"sub_a":"Etiqueta A","sub_b":"Etiqueta B"}
  }]
}
```
- Cada campo del PDF agrega su propia columna (nombre->nombre, motivo->motivo).
- Overflow: se puede dejar `overflow:null` con `overflowThreshold:1` para mapear a
  mano en Signframe.

## §10 repeaterLookup (preexistencias / enfermedades)

Campo del PDF (si/no) que marca "X" segun si una enfermedad fue seleccionada:
```jsonc
{"kind":"repeaterLookup","repeaterFieldId":"field_repeater_enfermedades","scope":"parent",
 "subFieldId":"enfermedad","needles":"\"Intolerante a la glucosa, Prediabetes o diabetes\"",
 "match":"equals","ifFound":"X","ifNotFound":""}
```
- Si el `needles` tiene coma, parentesis o barra (`,` `(` `)` `/`), envolverlo entre
  comillas dobles para que no rompa el parseo, tanto en el "si" como en el "no".
- El "si": `ifFound:"X"`, `ifNotFound:""`. El "no": `ifFound:""`, `ifNotFound:"X"`.

## §11 Notificacion

- Si el PDF TIENE campo de notificacion (con sourceMeta): dropdown medio
  (`descripcion`) + dato (`datosNotificacion`) visibles + el campo del PDF oculto
  que concatena medio + dato (autoFillConcat, separador `" - "`).
- Si el PDF NO tiene campo de notificacion: solo dropdown + dato al JSON (sin pintar).

## §12 Fecha partida (dia/mes/ano)

Cuando el PDF tiene 3 campos separados (DIA/MES/ANO) y el dato viene como
`fechaCreacion` = `YYYY-MM-DD`:
- 1 `field_fecha` visible (date picker) -> sale a `fechaCreacion`.
- 3 campos del PDF ocultos, al lado de `field_fecha`, con substring:
  ano `substring(0,4)`, mes `substring(5,7)`, dia `substring(8,10)`.

## §13 Observaciones multilinea

Textarea visible (`observaciones`) + las lineas del PDF ocultas que reparten el
texto por substring (ej. `0-70`, `70-180`, `180-290`). Visibilidad condicional
segun corresponda (p.ej. solo si "Tomador").

## §14 Paths del JSON destino (matriz vs destino real)

Verificar siempre contra el JSON destino real. Discrepancias conocidas
(matriz -> destino correcto):
- `datosFormulario.datosGenerales.personas[]` -> `datosFormulario.personas[]`.
- `...Consentimiento` (mayus) -> `consentimiento` (minus).
- `...dispotabilidadCarencia` (typo) -> `disputabilidadCarencia`.

Paths auxiliares sin slot en destino (radio de control, textos de "otro", montos
sin campo bool) -> `excludeFromJson:true`, sin `salidaJSON` (solo pintan o
controlan visibilidad).

## §15 Catalogos / codigos INS (recurrentes)

- Tipo ID tomador: Juridica Nacional=3, Gobierno=2, Institucion autonoma=4,
  Juridica extranjera=7.
- Moneda: Colones=CRC, Dolares=USD.
- Forma de pago: Mensual=MEN, Trimestral=TRI, Semestral=SEM, Anual=ANU.
- Notificacion: Correo Electronico, Domicilio Fisico, Otro.
- Ubicacion (provincia/canton/distrito): `options:[]` a la espera del catalogo INS.
- En `options`: `jsonValue` = codigo al JSON; `label` = lo que ve el usuario;
  `pdfValue` = lo que se escribe al PDF.


## §16 sourceNames con indice de array (repeaters)

Los repeaters del PDF traen sourceName con indice: `depGeneroFem[0]`,
`benefTitularNombre[3]`, `hipertensionFecha[1]`. El `id` del campo se sanitiza:
`[` `]` `.` -> `_`, colapsando repetidos y sin `_` final. Ej:
`depGeneroFem[0]` -> `field_depgenerofem_0`.

- Esto NO viola la regla de oro (§1): el sourceMeta.sourceName se conserva TAL CUAL
  (con los corchetes); solo el `id` va sanitizado.
- El validador acepta las 4 formas: `field_+sourceName`, su `.lower()`, y el
  sanitizado en ambos casos. Un id sanitizado de un `campo[N]` es correcto.
- En la matriz, estos widgets suelen quedar como sobrantes (§16) salvo el slot 0,
  porque la matriz lista el concepto una sola vez y el PDF lo repite por fila.

## §17 Visibilidad condicionada al contenido de un repeater (`__rep__:`)

Signframe soporta condicionar una subseccion (o un campo) a **lo que el usuario
eligio dentro de un repeater**, con un fieldId especial:

```
__rep__:<repeaterFieldId>:item:<subFieldId>
```

Ejemplo real (mostrar la seccion Diabetes solo si en el repeater de enfermedades
se cargo "Prediabetes y/o Diabetes"):

```jsonc
"conditionalVisibility": "{\"logic\":\"or\",\"conditions\":[
  {\"fieldId\":\"__rep__:field_repeater_enfermedades:item:enfermedad\",
   \"operator\":\"equals\",\"value\":\"Prediabetes y/o Diabetes\"}]}"
```

- `logic:"or"` con una condicion por valor que dispara (basta que una coincida).
- El `value` debe ser **identico** al `jsonValue`/`label` de la opcion del select.
- Sirve tanto a nivel subseccion como a nivel campo.
- El validador acepta este prefijo (igual que `__sub__:`).

## §18 PLAYBOOK: de PDF + matriz + main a form-def casi listo

El usuario **siempre** entrega estos **3 inputs** (el renombrado del PDF ya lo hizo
el con su propia herramienta). Si falta alguno, pedirlo antes de empezar:

1. **PDF renombrado** — idealmente tambien la version `*_con_labels.pdf`, que
   muestra cada sourceName sobre su campo: es la forma mas rapida y confiable de
   ubicar cada widget sin adivinar.
2. **Matriz** (xlsx) — define secciones, etiquetas publicas, tipo de dato, opciones
   de catalogo, reglas de visibilidad, obligatoriedad, maxLength y el path JSON.
3. **Main / export de Signframe** (`form-definition-*.json` recien cargado) — es la
   **unica fuente valida de `sourceMeta`** (posicion, nativeType, page).

Con mas material (capturas del render, JSON de salida de una prueba, un form-def
hermano ya aprobado) sale mejor, pero con esos tres alcanza para entregar algo
practicamente terminado.

Orden de trabajo:

- **Paso 0 — validar el PDF.** Contar duplicados en `_sourcePdf.fieldPositions`.
  Si un sourceName aparece 2 veces, el PDF esta mal renombrado y **falta** otro
  nombre: reportarlo con pagina y coordenadas (X/Y) para que el usuario lo corrija
  en su herramienta. No inventar el sourceMeta faltante ni seguir sin avisar.
- **Paso 1 — filtrar la matriz por formulario.** La columna *"Formulario a
  visualizar"* dice a que PDF aplica cada fila (`D0764 Completo`,
  `D0764 Completo / D0772 Abreviado`, vacio = solo JSON). Filtrar ANTES de armar:
  omitir este paso es la causa #1 de secciones faltantes. Las filas sin formulario
  son campos de `encabezado` que van ocultos con `prefillMode:"api"`.
- **Paso 2 — construir sobre el export.** Tomar los campos del main (sourceMeta
  correcto) y agregarles propiedades. Si se reusa un form-def previo, **pisar todos
  los `sourceMeta` con los del export nuevo**: entre renombrados cambian posicion
  y nativeType, y un sourceMeta viejo hace que el campo no pinte o pinte en el
  lugar equivocado.
- **Paso 3 — aplicar los patrones canonicos** (§19 a §23).
- **Paso 4 — validar** con `scripts/validate.py` hasta 0 ERROR, y revisar los WARN
  contra el checklist de §24.

Que preguntar cuando falte info (con botones, opciones cortas): indice base de
`personas[]`, si una tabla va con boton "Agregar" o con filas fijas visibles, y
cualquier regla de visibilidad de la matriz que sea ambigua.

## §19 Catalogo de labels y widths canonicos (Vital 360 / INS)

Reusar estos valores da consistencia entre formularios y evita el ida y vuelta.

**Bloque de persona (asegurado, dependiente mayor) — orden y ancho exactos:**

| # | Label | type | width | Notas |
|---|-------|------|-------|-------|
| 1 | Tipo de Identificacion (grupo) | radio | 1ro `half`, resto `third` | `radioGroupLabel` en el 1ro |
| 2 | Otro tipo de identificacion | text | `half` | visible si "Otro" |
| 3 | Identificacion | text | `half` | |
| 4-7 | Primer/Segundo Apellido, Primer/Segundo Nombre | text | `quarter` | |
| 8 | Nombre Completo | text | `full` | readOnly + `autoFillConcat` de los 4 |
| 9 | Fecha de Nacimiento | date | `quarter` | visible; las partes van ocultas |
| 10-12 | Dia/Mes/Anio nac. | text | `quarter` | **ocultas**, `substring` del date |
| 13 | Sexo (grupo) | radio | `third` | `radioGroupLabel: "Sexo"` |
| 14 | Edad | text | `quarter` | readOnly + autocalculada (§20) |
| 15-16 | Peso / Estatura | number | `half` | reglas de §8 |
| 17-18 | Telefono Celular / Correo electronico | number/text | `half` | |

**Pares Si/No:** el "Si" lleva `width:"full"` + `optionsLayout:"horizontal"` y el
"No" `width:null`. Asi el par ocupa la linea completa y el detalle que se despliega
cae limpio debajo. Con ambos en `full` caen en dos renglones (mal).

**Textos de pregunta:** van en `radioGroupLabel` del primer radio del grupo, NO en
el label (el label es la opcion). Sin esto, el render muestra la primera opcion
como titulo del grupo.

**Anchos por tipo de dato (default):** fechas partidas y montos chicos `quarter`;
identificaciones, telefonos, correos, peso/estatura `half`; combos de catalogo
`third`; textareas y explicaciones `full`.

## §20 Fecha de nacimiento y edad autocalculada

- **Fecha**: un campo `date` **visible** (sin sourceMeta) que el usuario llena.
  Los 3 campos del PDF (dia/mes/anio) quedan `hidden:true` + `readOnly` y extraen
  su parte con `transforms:[{"kind":"substring","start":S,"end":E}]` sobre el date
  (formato `YYYY-MM-DD`): anio `0..4`, mes `5..7`, dia `8..10`.
- **Edad**: `readOnly` + `autoFillConcat` con `dateRef`:
  ```jsonc
  {"sourceFieldIds":["<id_date>"],"separator":" ","parts":[
    {"kind":"dateRef","ref":"today","offsetDays":0,"op":"diffYears"},
    {"kind":"field","fieldId":"<id_date>","op":"diffYears"}]}
  ```

## §21 Bloques repetidos (dependientes, beneficiarios): subsecciones fijas + botones

Los repeaters con `slotMappings` **no siempre vuelcan al PDF**. El patron que si
funciona (y que usa el 5919) es **N subsecciones fijas**, una por item, con cada
campo mapeado directo a su slot `campo[N]`:

- Subseccion por item con `id` propio (`sub_depmen_1`, `sub_benef_tit_1`, ...).
- Item 1 visible (o condicionado a la pregunta "¿desea incluir?"); items 2..N con
  `conditionalVisibility` NEVER.
- **Boton "Agregar"** (`bgColor:"#32898f"`) con `showSubsectionIds:[<siguiente>]`
  y `hideFieldIds:[<el propio boton>]`.
- **Boton "Quitar"** (`bgColor:"#ff0000"`) con `clearOnHide:true` y
  `hideSubsectionIds:[<la propia>]`.
- Campos del PDF con `sharedValue:true` para que vuelquen.
- Indices: asegurado `personas[0]`, dependientes `personas[1..N]`; los
  beneficiarios suelen colgar de un sub-array (`personas.beneficiariosTitular[i]`).

**Importante — NEVER a nivel campo bloquea a los botones.** Si un campo (no una
subseccion) tiene `conditionalVisibility` NEVER, ningun boton puede mostrarlo: la
condicion gana. Para filas que revela un boton, usar `hidden:true` **sin**
`conditionalVisibility`.

## §22 Suma de porcentajes que debe dar 100

Campo oculto que suma los porcentajes y falla la validacion si no da 100:

```jsonc
{"id":"field_suma_beneficiarios","type":"text","hidden":true,"required":true,
 "excludeFromJson":true,"validationPattern":"^100$",
 "validationErrorMessage":"El porcentaje total asignado a los beneficiarios debe sumar exactamente 100%.",
 "autoFillConcat":{"sourceFieldIds":[...pcts],"separator":" ",
   "parts":[{"kind":"field","fieldId":"<pct>","op":"sum"}, ...]},
 "validationHighlights":[{"id":"vh_1","fieldId":"<pct>","condition":{"operator":"not_empty","value":null}}]}
```

## §23 Declaraciones: un checkbox maestro marca todas

Un unico checkbox visible y obligatorio; las declaraciones reales del PDF quedan
ocultas y lo copian:

```jsonc
// esclava (una por cada declaracion del PDF)
{"hidden":true,"readOnly":true,"checkedPdfValue":true,
 "autoFillConcat":{"sourceFieldIds":["field_decl_solicitud"],"separator":" ",
   "parts":[{"kind":"field","fieldId":"field_decl_solicitud","valueSource":"visible"}]}}
```
Los textos legales largos van en la `description` de la subseccion.

## §24 Errores frecuentes (checklist de revision rapida)

1. **`radioGroupFields` con mayusculas.** Los `id` son minusculas
   (`field_monedadolares`); si la referencia lleva mayusculas el grupo NO se forma
   y los radios se ven como texto suelto sin casillas. Revisar case en TODAS las
   referencias (`radioGroupFields`, `conditionalVisibility`, `autoFillConcat`).
2. **NEVER que bloquea el pintado.** Un slot oculto con NEVER no vuelca al PDF.
   Para ocultar algo que igual debe pintar: `hidden:true` y `conditionalVisibility:null`.
3. **`order` duplicado o `null`.** Provoca campos que "aparecen de la nada" o en
   posicion aleatoria. Reasignar 1..N por subseccion.
4. **needles de `repeaterLookup` con comillas.** Con `match:"equals"` el needle NO
   debe ir entre comillas: se compara literal contra el valor del select.
5. **Disparadores desalineados.** Si el detalle depende de una pregunta distinta a
   la que activa el repeater/seccion, nunca se muestra. Verificar que apunten al
   mismo campo.
6. **Pares Si/No invertidos.** Revisar que el campo `*si` tenga `label:"Si"` y
   `jsonValue:"Si"` (se han visto exports con label y jsonValue cruzados, lo que
   hace que todos los condicionales funcionen al reves).
7. **Casillas cruzadas en el PDF.** Si al marcar "Masculino" pinta "Femenino", el
   slot esta cruzado: se corrige intercambiando label+jsonValue entre los dos
   campos, **sin tocar el sourceMeta**.
