# Cookbook — snippets copy-paste (sacados del 5919 real)

Pegá y cambiá ids/valores. Todos los checks del validador aplican. Para el detalle
del porqué, ver `conventions.md`.

## Campo del PDF (base, no tocar sourceMeta)
```jsonc
{ "id":"field_<sourcename_lower>", "type":"text", "label":"...",
  "readOnly":false, "hidden":true, "order":<n>,
  "sourceMeta":{"sourceName":"<sourceNameTalCualPDF>","page":1,"nativeType":"Text","rect":{...}},
  "salidaJSON":"datosFormulario...." }
```
Regla: `id == "field_" + sourceName.lower()`. sourceName = EXACTO del PDF (incluye typos).

## Radio desdoblado Sí/No (con order propio, nunca 0)
```jsonc
{ "id":"field_x_si","type":"radio","label":"Sí","radioGroupLabel":"¿Pregunta?",
  "radioGroupFields":["field_x_no"],"jsonValue":"true","pdfValue":"X","order":10 },
{ "id":"field_x_no","type":"radio","label":"No",
  "radioGroupFields":["field_x_si"],"jsonValue":"false","pdfValue":"X","order":11 }
```

## Checkbox de texto que PINTA (helper oculto)
```jsonc
"autoFillConcat":{"sourceFieldIds":[],"separator":"","parts":[
  {"kind":"text","value":true,"condition":{"fieldId":"field_select","op":"equals","values":"Cédula física"}}
]}
```
Ojo: `value:true` (booleano) para que pinte. `op:equals` usa `values` (con s).

## repeaterLookup (preexistencias: marca X si la enfermedad fue elegida)
```jsonc
"autoFillConcat":{"sourceFieldIds":[],"separator":"","parts":[
  {"kind":"repeaterLookup","repeaterFieldId":"field_repeater_enfermedades","scope":"parent",
   "subFieldId":"enfermedad","needles":"\"Intolerante a la glucosa, Prediabetes o diabetes\"",
   "match":"equals","ifFound":"X","ifNotFound":""}
]}
```
needles con `, ( ) /` → envolver en comillas dobles. "si": ifFound X. "no": ifNotFound X.

## repeaterAggregate (pinta una columna del repeater)
```jsonc
"autoFillConcat":{"sourceFieldIds":[],"separator":" ","parts":[
  {"kind":"repeaterAggregate","repeaterFieldId":"field_<rep>","scope":"parent",
   "subFieldIds":["embarazo_nombre"],"separator":", ","group":true,
   "groupFieldIds":[],"groupSeparator":" ","subFieldLabels":{"embarazo_nombre":"Nombre Completo"}}
]}
```

## Fecha partida (día/mes/año desde YYYY-MM-DD)
```jsonc
// campo visible: field_helper_fecha_nac (date picker) -> sale a fechaNacimiento
// 3 campos del PDF ocultos, uno por parte:
"autoFillConcat":{"sourceFieldIds":["field_helper_fecha_nac"],"separator":"-","parts":[
  {"kind":"field","fieldId":"field_helper_fecha_nac","transforms":[{"kind":"substring","start":8,"end":10}]}
]}
// día substring(8,10) · mes (5,7) · año (0,4)
```

## conditionalVisibility (string JSON, fieldId con field_)
```jsonc
"conditionalVisibility":"{\"logic\":\"and\",\"conditions\":[{\"fieldId\":\"field_x_si\",\"operator\":\"not_empty\"}]}"
```
Dentro de un repeater, un subcampo puede referenciar a otro subcampo hermano por su
id pelado (sin field_).

## Sección/subsección siempre oculta (NEVER)
```jsonc
"conditionalVisibility":"{\"logic\":\"and\",\"conditions\":[{\"fieldId\":\"field_NEVER_EXISTS\",\"operator\":\"not_empty\"}]}"
```

## Formato numérico CR
- Monto: `"jsonNumberFormat":"#.##0,00","thousandsSeparator":".","decimalSeparator":",","decimalPlaces":2`
- Entero miles: `"jsonNumberFormat":"#.##0","thousandsSeparator":".","decimalSeparator":null,"decimalPlaces":0`
- Porcentaje: `"jsonNumberFormat":"00.00","decimalSeparator":",","decimalPlaces":2,"maxLength":5`

## sourceName con indice de array (repeater slot)
```jsonc
// sourceName TAL CUAL del PDF (con corchetes); id sanitizado [ ] . -> _
{ "id":"field_depgenerofem_0", "type":"checkbox", "label":"Dep Genero Fem[0]",
  "sourceMeta":{"sourceName":"depGeneroFem[0]","page":1,"nativeType":"Checkbox","rect":{...}} }
```
Regla: `id == "field_" + sanitize(sourceName)` donde sanitize = `[ ] .`->`_`. El
sourceName NO se toca. El validador lo acepta como correcto.


## Par Si/No (el patron correcto de ancho)
```jsonc
// El "Si": ocupa la linea + layout horizontal + la PREGUNTA en radioGroupLabel
{"id":"field_riesgo4alcoholsi","type":"radio","label":"Sí","jsonValue":"Si",
 "width":"full","optionsLayout":"horizontal","checkedPdfValue":true,
 "radioGroupLabel":"¿Utilizan bebidas alcohólicas?",
 "radioGroupFields":["field_riesgo4alcoholno"]}
// El "No": width null (si va full, cae en otro renglon)
{"id":"field_riesgo4alcoholno","type":"radio","label":"No","jsonValue":"No",
 "width":null,"optionsLayout":"horizontal","checkedPdfValue":true,
 "radioGroupFields":["field_riesgo4alcoholsi"]}
```

## Fecha de nacimiento: date visible + partes ocultas
```jsonc
// visible (UI, sin sourceMeta)
{"id":"field_titular_fechaNac","type":"date","label":"Fecha de Nacimiento",
 "width":"quarter","jsonDateFormat":"YYYY-MM-DD","placeholder":"dd/mm/aaaa",
 "salidaJSON":"datosFormulario.personas[0].fechaNacimiento"}
// parte dia (slot PDF, oculta)
{"id":"field_titularfechanacdia","hidden":true,"readOnly":true,"excludeFromJson":true,
 "autoFillConcat":{"sourceFieldIds":[],"separator":"","parts":[
   {"kind":"field","fieldId":"field_titular_fechaNac",
    "transforms":[{"kind":"substring","start":8,"end":10}]}]}}
// mes -> start 5 end 7 | anio -> start 0 end 4
```

## Edad autocalculada
```jsonc
{"id":"field_titularedad","type":"text","label":"Edad","width":"quarter","readOnly":true,
 "autoFillConcat":{"sourceFieldIds":["field_titular_fechaNac"],"separator":" ","parts":[
   {"kind":"dateRef","ref":"today","offsetDays":0,"op":"diffYears"},
   {"kind":"field","fieldId":"field_titular_fechaNac","op":"diffYears"}]}}
```

## Visibilidad segun lo cargado en un repeater (§17)
```jsonc
"conditionalVisibility": "{\"logic\":\"or\",\"conditions\":[
  {\"fieldId\":\"__rep__:field_repeater_enfermedades:item:enfermedad\",
   \"operator\":\"equals\",\"value\":\"Presión arterial alta\"}]}"
```

## Botones agregar/quitar item (subsecciones fijas, §21)
```jsonc
{"id":"btn_add_depmen_1","type":"button","label":"Agregar otro dependiente","width":"third",
 "buttonConfig":{"bgColor":"#32898f","showSubsectionIds":["sub_depmen_2"],
                 "clearOnHide":false,"hideFieldIds":["btn_add_depmen_1"]}}
{"id":"btn_rm_depmen_2","type":"button","label":"Quitar dependiente","width":"third",
 "buttonConfig":{"bgColor":"#ff0000","clearOnHide":true,"hideSubsectionIds":["sub_depmen_2"]}}
```
Las filas/subsecciones que revela un boton NO deben tener `conditionalVisibility`
NEVER a nivel campo: usar `hidden:true` a secas (§21).

## Label HTML (tablas de coberturas, textos informativos)
```jsonc
{"id":"field_cobertura_plan1","type":"label","label":"Coberturas Esencial 1",
 "width":"full","defaultValue":"<div>...tabla HTML...</div>",
 "conditionalVisibility":"{...si el plan 1 esta marcado...}"}
```
