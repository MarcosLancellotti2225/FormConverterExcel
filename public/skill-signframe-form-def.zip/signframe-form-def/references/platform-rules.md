# Reglas de plataforma Signframe (verificadas contra el codigo fuente)

Todo lo de acá está leído de `front/src/services/formDataTransform.ts`,
`front/src/components/RepeaterField.tsx` y
`back/src/Signaturit.SignaFrame.Consumer/Handlers/SendClientCallbackQueueMessageTypeHandler.cs`.
No son suposiciones: si algo contradice esta página, gana esta página.

---

## §P1 — `jsonOutputPath` es la ruta de salida, no `salidaJSON`

`setBoth()` lee **solo** `fieldInfo.jsonOutputPath`. `salidaJSON` no se usa en la
transformación.

```js
const path = (fieldInfo?.jsonOutputPath ?? '').trim();
if (!path) return;          // sin ruta -> el campo NO aparece en el JSON
```

En la práctica se escriben los dos iguales para que el editor y las herramientas
externas los vean, pero **si difieren, manda `jsonOutputPath`**.

**La salida es opt-in**: sin ruta, el campo no sale en el JSON (pero sí en el PDF).

---

## §P2 — Booleanos: solo `type: "boolean"` emite `true`/`false` nativos

```js
// checkbox / radio
const json = f?.checkedJsonValue != null && f.checkedJsonValue !== ''
  ? f.checkedJsonValue    // se emite como STRING
  : true;                 // booleano, pero SIEMPRE true

// type: "boolean"
const b = s === 'true' || s === '1' || s === 'x' || s === 'si' || s === 'sí';
setBoth(key, b ? 'Sí' : 'No', b, field);   // booleano real, true Y false
```

Consecuencias:

- Un radio **nunca** puede emitir `false` nativo. Con `checkedJsonValue: "false"`
  sale `"false"` string; vacío sale `true`.
- Para un indicador booleano se necesita un helper `type: "boolean"`, oculto, que
  lea el grupo de radios por `autoFillConcat` y produzca `"true"`.
- Los radios del grupo quedan con `jsonOutputPath: null`: siguen pintando el PDF
  (el PDF se escribe antes de mirar la ruta) y dejan de escribir JSON.

Patrón en `patterns.md §P-BOOL`.

**Limitación**: el helper no distingue "respondió que no" de "no respondió". Los
dos dan `false`.

---

## §P3 — Números y tipado de selects

`type: "number"` se emite numérico:

```js
if (parsed != null) return parsed;   // numero real, no String(parsed)
```

Excepción: si hay `jsonNumberFormat` y el texto formateado no es un número JSON
válido (separador de miles, coma decimal — `"1.234,56"`), se conserva string.

`type: "text"` con contenido numérico sale string. Si el destino espera número,
el campo se declara `number`.

### `selectJsonValueType`

Un `select` puede declarar cómo se tipa su `jsonValue`:
`"text"` (default) | `"number"` | `"boolean"`.

```js
if (type === 'number') { const n = Number(text.replace(',', '.'));
                         return Number.isFinite(n) ? n : raw; }
// boolean: true  <- true,1,si,sí,x,y,yes
//          false <- false,0,no,n
```

Si el valor no se puede parsear, queda como texto. Aplica tanto a campos de nivel
sección como a **subcampos de repeater**.

Es la forma de resolver un código de catálogo que el destino quiere numérico
(provincia, cantón, distrito, tipo de identificación).

---

## §P4 — Repeaters: manda `repeaterConfig.jsonSlotPattern`

El bucle de repeaters es independiente del bucle de campos normales:

```js
for (const f of fields) {
  if (f.type !== 'repeater' || !f.repeaterConfig) continue;
  ...
  const parentPattern = cfg.jsonSlotPattern || `${bare}[{i0}].{sub}`;
```

Reglas que salen de ahí:

1. **`excludeFromJson` NO apaga un repeater.** El bucle no lo mira. La única forma
   de que un repeater no emita es dejar `jsonSlotPattern` vacío o `null`.
2. **Si el patrón falta, usa un default con el id del campo** → aparece una clave
   con el id crudo en la raíz del JSON (ej. `"1781778628538": [...]`).
3. **`jsonOutputPath` en un repeater es un bug**: el bucle de campos normales
   escribe el valor interno crudo del repeater en esa ruta, y sale
   `"[object Object]"` o el JSON escapado con `id`/`values`/`children`.
   Los repeaters van con `jsonOutputPath: null` y `salidaJSON: null`.
4. Si `items.length === 0`, no se emite nada de ese repeater.

### Placeholders

| Token | Significado |
|---|---|
| `{i}` / `{i0}` | índice del item, 0-based |
| `{i1}` | índice del item, 1-based |
| `{j}` / `{j0}` | índice del subitem, 0-based |
| `{j1}` | índice del subitem, 1-based |
| `{sub}` | id del subcampo |

Para arrays JSON usar siempre 0-based. Con `{i1}` la posición 0 del array queda
en `null`.

En el patrón de slots **PDF** (`slotPattern`) `{i}` y `{j}` son 1-based.

---

## §P5 — Subrepeater (`repeaterConfig.child`)

- **Uno solo por repeater** y **un solo nivel** de anidación. No hay sub-sub.
- **No tiene visibilidad condicional.** El render es
  `{cfg.child && <ChildRepeater ... />}`: si existe, se dibuja siempre.
- **Un subcampo del subitem no ve los campos del item padre.** `SubfieldGrid`
  llama `isFieldVisible(f, values, fields)` donde `values` son solo los del
  subitem.

Consecuencia práctica: si un bloque anidado debe aparecer solo para ciertos
valores del item padre, **el subrepeater no sirve**. Hay que usar campos planos
del item con `conditionalVisibility` contra un subcampo hermano.

---

## §P6 — Los subcampos de repeater no pasan por el mapeo de tipos

```js
const val = formatSubVal(sf, item?.values?.[sf.id]);   // solo formatea fechas
setByPath(json, path, sf.id, val ?? '');
```

Dentro de un repeater, `formatSubVal` resuelve:

- `date` -> `jsonDateFormat` / `dateFormat`
- `time` -> `jsonTimeFormat`, con `timeZone` y `timeIncludeOffset`
- `number` -> numérico real, respetando `jsonNumberFormat`
- `select` -> su `jsonValue`, tipado según `selectJsonValueType`

Lo que **no** resuelve: `type: "boolean"` dentro de un repeater no emite booleano
nativo. Para un booleano dentro de un array hay que usar un `select` con
`selectJsonValueType: "boolean"`.

**Además, se emiten TODOS los subcampos de TODOS los items**, aunque estén
ocultos por condición. Los que no aplican salen como `""`.

---

## §P7 — Los subcampos de repeater no pintan PDF

No llevan `sourceMeta`. El PDF se pinta desde afuera con `slotPattern`
(nombres de campo por item × subcampo) o con `repeaterAggregate` /
`repeaterLookup` en un campo que sí tiene `sourceMeta`.

---

## §P8 — Visibilidad condicional: alcance

| Dónde está el campo | A qué puede apuntar `fieldId` |
|---|---|
| Sección o subsección | ids globales, con prefijo `field_` |
| Subcampo de repeater | ids **pelados** de subcampos hermanos del mismo item |
| Subcampo de subrepeater | solo subcampos hermanos del subitem |

**Una condición que apunta a un id inexistente no falla: se ignora en silencio**
y el campo queda visible. Es la causa más común de "el campo aparece donde no
debería".

`conditionalVisibility` tiene un único `logic` para todo el bloque. No se pueden
mezclar `and` y `or` en la misma condición (ej. "una de estas 4 categorías **y**
además el indicador en Sí").

---

## §P9 — Escribir sin índice sobre un nodo que ya es array

`setByPath` no reemplaza un array por un objeto:

```js
// Never replace the array with an object; write the index-less child path
child = isObjectLike(first) && !Array.isArray(first) ? first : {};
existing[0] = child;
```

Una ruta sin índice sobre un nodo que ya es array escribe en **`[0]`**. Por eso
un campo suelto con `embarazo.indicador` termina en `embarazo[0].indicador`
cuando un repeater ya creó el array.

Al revés también: si primero escribe el objeto y después llega un índice, el
objeto se envuelve en array.

**Aun así, no conviene depender de esto**: si un repeater es dueño de un nodo,
los campos sueltos que escriben ese mismo nodo van a `excludeFromJson: true`.

---

## §P10 — Índices de arrays padre

El repeater resuelve **su** índice y el de su hijo. Los índices de los arrays de
arriba van escritos a mano en el patrón:

```
datosFormulario.personas[0].riesgo[0].enfermedades[{i0}].{sub}
                        ^^^        ^^^  a mano
```

Lo mismo para campos normales: `personas[0].direccion[0].codigoProvincia`.

**Qué nodo es array depende del producto, no es una lista fija.** Hay productos
donde `personas[].direccion` es un **objeto** y solo `riesgo` y
`mediosNotificacion` son arrays. Deducir siempre los nodos array del JSON de
ejemplo del cliente; hardcodear la lista produce falsos positivos sistemáticos
(el linter lo hacía con `direccion` y marcaba 5 errores inexistentes).

---

## §P11 — Nulls del payload de entrada

Está implementado y funciona:

```js
for (const { key, path } of options?.nullJsonPaths ?? []) {
  const existing = getByPath(json, p);
  if (existing !== undefined && existing !== '' && existing !== null) continue;
  setByPath(json, p, key, null);
}
```

Si el JSON de precarga traía `null` en una ruta y el campo que se prellena desde
ahí está mapeado a esa ruta de salida, el `null` se reenvía explícito. El backend
lo respeta (test `SendClientCallbackQueueMessageTypeHandlerNullTests`).

Si un campo no vuelve en `null`, revisar el `prefillKey` / `jsonOutputPath` del
campo, no reportar bug de plataforma.

---

## §P12 — Orden de las claves raíz

Forzado en los dos lados: `orderJsonRootKeys()` en el front y `ReorderRootKeys()`
en el back. Siempre `encabezado`, después `datosFormulario`, después el resto.

No hace falta ordenar secciones para conseguirlo. Si una herramienta externa
muestra otro orden, es de la herramienta.

---

## §P13 — `autoFillConcat`: las condiciones necesitan `sourceFieldIds`

Un `autoFillConcat` con condiciones solo se re-evalúa si los `fieldId` de esas
condiciones están listados en `sourceFieldIds`. Sin eso, el helper escribe
siempre, sin importar la condición.

```json
"autoFillConcat": {
  "sourceFieldIds": ["field_ancla"],
  "separator": "",
  "parts": [
    { "kind": "text", "value": "Persona Beneficiaria",
      "condition": { "fieldId": "field_ancla", "op": "notEmpty" } }
  ]
}
```

Operadores (camelCase): `notEmpty`, `empty`, `equals`, `notEquals`, `contains`.
`equals` y `notEquals` usan la clave `values`.

---

## §P14 — Helpers ocultos y entradas fantasma

Un campo `hidden: true` escribe **siempre**, aunque tenga `conditionalVisibility`.
Un helper con `defaultValue` fijo y sin condición efectiva genera entradas
fantasma en los arrays de personas (`{"descripcionTipo": "..."}` sin más datos).

Para que un helper escriba solo cuando corresponde: sin `defaultValue`, con
`autoFillConcat` condicionado, y con el ancla en `sourceFieldIds` (§P13).

---

## §P15 — Firmas

Los campos `type: "signature"` se saltean en la transformación (`continue`), así
que no aportan al JSON. Su cableado es:

```
prefillKey                     -> correo del firmante
signatureSignerNamePrefillKey  -> nombre del firmante
signatureCcPrefillKey          -> correo en copia
```

`sourceMeta.sourceName: null` en una firma es normal: no son AcroForms de texto.
Ojo que el `rect` de una firma usa minúsculas (`x/y/width/height`) mientras que
el de un AcroForm usa mayúsculas (`X/Y/Width/Height`).

---

## §P16 — Campos de hora

Propiedades disponibles: `timeFormat`, `pdfTimeFormat`, `jsonTimeFormat`,
`timeStep`, `timeZone`, `timeIncludeOffset`. Funcionan tanto a nivel campo como
en subcampos de repeater.

---

## §P17 — Listas precargadas (`PresetList`)

La entidad tiene `JsonValueType` con los mismos tres valores que
`selectJsonValueType`: `text` (default), `number`, `boolean`. Un catálogo puede
declarar el tipo de salida una vez, en vez de repetirlo campo por campo.

Validación del backend: `JsonValueType must be one of: text, number, boolean.`

---

## §P18 — Un select prefillado llega con el `jsonValue`, no con la etiqueta

Cuando un `select` (o `radio`) recibe su valor del payload de entrada vía
`prefillKey`, lo que se inyecta es el **`jsonValue` de la opción**, no el
`label`. Toda condición que compare ese campo —`conditionalVisibility` o
`condition` de una parte de `autoFillConcat`— tiene que cubrir **las dos
formas**, o no matchea nada.

Síntoma: el formulario se abre con la sección vacía y el PDF sale en blanco en
ese bloque, sin ningún error. La condición simplemente no se cumple (§P8: una
condición que no matchea no falla, se ignora).

Caso tipico: `codigoTipo` viene en la petición que inicia el proceso con valor
`"ASG"`, y las condiciones del form-def comparan contra
`"Persona Asegurada Directa"`. En un producto salieron 82 condiciones asi.

Cómo cubrir cada una:

| Dónde | Cómo |
|---|---|
| `conditionalVisibility` con `equals` | agregar una condición hermana con el código y poner `logic: "or"` |
| `autoFillConcat` con `op: "equals"` | duplicar la parte, con el código en `values` |
| `autoFillConcat` con `op: "notEquals"` | **NO duplicar**: reescribir como `equals` sobre los otros valores, en etiqueta y en código |

El `notEquals` es la trampa. Duplicarlo emite dos veces, porque
`notEquals "Persona Jurídica"` y `notEquals "JRD"` son **ambos verdaderos** a la
vez para cualquier otro valor, y el `separator` queda en el medio.

Recordar que las dos estructuras no comparten claves: `conditionalVisibility`
usa `operator` + `value` (singular), `autoFillConcat` usa `op` + `values`.

Lo chequea `lint_platform.py` como §P18: solo marca error si aparece una
etiqueta y **no** aparece también su `jsonValue` para el mismo campo apuntado.

---

## §P19 — Signframe guarda el form-def tal cual, y subirlo no regenera `_sourcePdf`

Dos consecuencias verificadas subiendo y volviendo a bajar el mismo archivo:

1. **Round-trip byte a byte.** El form-def que baja es idéntico al que subió: no
   se normaliza, no se completa y no se valida nada. Un `sourceFieldIds` vacío o
   una ruta mal escrita no dan error al guardar; se descubren recién en el
   payload de salida. Por eso el chequeo tiene que correrse afuera.
2. **`_sourcePdf` se arma al importar el PDF, no al guardar el JSON.** Si falta
   un campo en `fieldPositions`, volver a subir el form-def no lo agrega. Hay que
   reimportar el PDF, y lo que baja de ahí es el **main pelado** (una sola
   sección `Main`, `version: 1`, sin secciones ni helpers). El enriquecido se
   conserva aparte y se le trasplanta el `sourceMeta` que faltaba.
