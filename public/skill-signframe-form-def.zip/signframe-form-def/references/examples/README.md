# Ejemplos de oro

Form-defs reales que sirven de plantilla de estructura y estilo.

- `5919-gastos-medicos-golden.json` — **referencia principal**. Seguro Médico
  Colectivo (Gastos Médicos Completo, 5919). 7 páginas, ~580 AcroForms, 802 campos,
  7 secciones. Ejercita todos los patrones difíciles: repeaters con agregadores
  (`repeaterAggregate`), `repeaterLookup` para preexistencias, `slotMappings`,
  fechas partidas (día/mes/año), checkboxes desdoblados, secciones ocultas con
  NEVER, y slots ocultos de dependientes. Trae la lista real de AcroForms embebida
  en `_sourcePdf.fieldPositions` (ground truth para cruzar sourceName).

  Notas de este archivo (no copiar como ideal):
  - Convención de ids en MINÚSCULA: `id == "field_" + sourceName.lower()`.
  - Quedan ~8 campos sin AcroForm en el PDF (defectos del PDF INS: inmunodeficiencia,
    otra-condición-congénita "No", otros-padecimientos "Sí"). No pintan; pendientes
    de decisión con la matriz.
  - El orden de varios radios Sí/No está pendiente de normalizar.

- `vital360-merge-repeaters.json` — **Vital 360° (D0764)**. 390 campos, 8 paginas.
  Segundo ejemplo, complementario al 5919. Ejercita lo que el 5919 no muestra tan
  claro: doble juego de asegurado (`titular*` directo vs `depTit*` dependiente
  mayor), repeaters de dependientes (`dep*[0..4]`) y beneficiarios
  (`benefTitular*[0..3]` / `benefDep*[0..3]`) con sourceName indexado (§16),
  y ~96 checkboxes Si/No de enfermedades (`enf*`) que una matriz del cliente
  colapsa en pocas filas (caso de sobrantes de §16). Pasa el validador con 0 ERROR.
  Sirve como caso de referencia para "preparar la matriz" con `scripts/map_matriz.py`.

- `d0772-abreviado-desde-matriz.json` — **D0772 Vital 360 Abreviado**. 304 campos,
  6 secciones, 167 sourceName. Ejemplo del circuito completo de §18: armado desde
  cero con PDF renombrado + matriz + export de Signframe. Muestra en un solo archivo
  casi todos los patrones canonicos: bloques de persona con los anchos de §19,
  fecha de nacimiento date+partes ocultas y edad autocalculada (§20), dependientes
  y beneficiarios como subsecciones fijas con botones agregar/quitar (§21), suma de
  porcentajes con validacion 100% (§22), checkbox maestro de declaraciones (§23),
  planes con labels HTML de coberturas condicionados, y campos UI que alimentan
  slots ocultos del PDF (Datos Adicionales -> Eleccion de Opciones).
