# Etapa 0 — el PDF, antes de que Signframe lo importe

Lo que el importador de Signframe necesita del AcroForm. Un PDF puede verse
perfecto en Acrobat y aun así perder campos al importar: lo que importa es la
estructura interna, no lo que se ve.

Chequeo automático: `python3 scripts/check_pdf.py <pdf>`.

---

## §E1 — Cada widget tiene que llevar su `/FT` propio

El importador recorre los widgets (`/Subtype /Widget`) y lee el tipo en el
**mismo diccionario**. Si el campo está partido en dos niveles —el padre con
`/T` y `/FT`, el hijo con `/Rect` y `/AP`— el widget no tiene `/FT` propio y el
importador lo **saltea en silencio**.

```
padre   → /T /FT /DA /Kids        (sin /Rect, sin /Subtype)
  └ hijo → /Rect /AP /AS /MK /F   (sin /T, sin /FT)
```

Síntoma: el main baja con N-1 campos y `_sourcePdf.fieldPositions` con N-1
entradas, sin ningún mensaje. Reimportar no lo arregla (§P19).

Es el mismo problema que `pdf-lib` tiene con los campos jerárquicos tipo
`Text3.0.0`, pero puede aparecer en **un solo campo suelto** de un PDF por lo
demás plano — que es el caso difícil de ver, porque en Acrobat se ve igual que
sus hermanos.

Caso real: en un formulario de 202 campos, un solo checkbox estaba así. Su
hermano de al lado, tres milímetros arriba y creado en la misma pasada, estaba
plano. Costó seis reimportaciones encontrarlo.

**Arreglo**: aplanar — subir `/FT` y `/DA` al hijo, ponerle el `/T`, y
reemplazar el padre por el hijo en `/AcroForm/Fields`. O borrarlo y recrearlo
copiando un hermano sano.

---

## §E2 — Un checkbox necesita `/FT /Btn`, `/AP` y `/DA`

Cuando se crea un campo a mano (en Acrobat o en una herramienta propia), lo que
suele salir mal:

| Propiedad | Qué pasa si falta o está mal |
|---|---|
| `/FT` = `/Btn` | si sale `/Ch`, Signframe lo importa como `multiselect` y no se puede marcar |
| `/AP` con `/N` | sin apariencia no dibuja el tilde, y el `autoFillConcat` no lo pinta |
| `/DA` | hereda mal la fuente del glifo (`/ZaDb 9 Tf 0 g` en los del INS) |
| estado de exportación | en los formularios del INS es **`Sí`**, con tilde. `Yes`/`On` no matchean |

**La forma segura de crear uno**: copiar un checkbox hermano ya sano del mismo
PDF, pegarlo, moverlo a su posición y solo cambiarle el nombre. Así hereda tipo,
`/AP`, `/DA` y estado de exportación, y no hay nada que puedas olvidarte.

Como el `sourceName` es inmutable y el `id` se deriva de él (Regla de Oro), un
campo mal creado **no se arregla del lado del JSON**: hay que rehacerlo en el
PDF y reimportar.

---

## §E3 — Lo que hay que verificar antes de subir a Signframe

1. `widgets == nombres únicos` — 0 multi-widget no intencionales.
2. 0 widgets sin `/FT` propio (§E1).
3. 0 nombres fuera de `[a-z0-9_]` — sin acentos, espacios ni puntos.
4. 0 valores sucios: `/V`, `/DV`, `/TU`, `/TM` heredados del original.
5. Todos los `/Btn` con `/DA` y con `/AP/N`.
6. El conteo coincide con el paquete de campos y con el form-def anterior, si lo
   hay. Un campo de más suele ser un duplicado que quedó al recrear otro.

Después de importar, confirmar que `_sourcePdf.fieldPositions` tiene el total
esperado. Si no coincide, el problema está en el PDF, no en el JSON.
